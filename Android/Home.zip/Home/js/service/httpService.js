kexApp.service("httpService", ["$http","$q", function($http,$q) {
	var userInfo = {};
	return {
		getUserInfo: function() {
			// 如果已存在则直接返回
			if(userInfo.name) {
				return $q.when(userInfo);
			}
			//如果不存在数据则加载
			return $http.get('http://k.kankexue.com/Books/updateBook/index.php').then(function(res) {
				// 把数据存到server中并返回
				return res.data;
			})
		},
		getImages:function(file){
			var apiUrl = kexAppJson.config.apiUrl;
			var apiKey = kexAppJson.config.apiKey;
			return $http({
				url:apiUrl,
				method:'POST', data:file,
				headers: {
					"Content-Type": "application/octet-stream",
					"Ocp-Apim-Subscription-Key": apiKey
				}
			});

		},
		getImagesFromDatabaseByTags:function(tags){
			var user = JSON.parse(localStorage.getItem("user"));
			var token=user.token;
				return	$http({
					   url:kexAppJson.config.imgSearch+tags,
					   method:'GET',  
					   params:{
						   	token:token
					    }
			  		})
		},
		getContent:function(contentT){
			return $http({
				url:kexAppJson.config.contentSearch + contentT,
				method:'GET',
				headers:{
					'Accept':  'application/json'
				}
			})
		},
		getClassifyList:function(){
			return $http({
				url:kexAppJson.config.classify,
				method:'GET'
			});
		},
		getListsFromSub:function(sub){
			return $http({
				url:kexAppJson.config.getListsFromClass + sub,
				type:'GET',
				params:{'token':token}
			});
		},
		getTags:function(token){
			
			return $http({
				url:kexAppJson.config.getTags,
				method:'GET',
				params:{'token':token}
			})
		},
		getTagList:function(token,tagName){
			return $http({
				url:kexAppJson.config.getTagList+tagName,
				type:'GET',
				params:{'token':token}
			});
		},
		getComment:function(id,page){
			return $http({
				url:kexAppJson.config.getComment+id,
				method:'GET',
				params:{start:page,token:token}
			})
		},
		payMoney:function(token,id,type){
			return $http({
				url:kexAppJson.config.payModey,
				method:'POST',
				headers:{
					'token': token
				},
				params:{
					'id' : id,
					'type' : type
				}
			});
		}
	}
}])