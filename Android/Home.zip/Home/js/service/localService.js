kexApp.service('localService',function(){
    return {
        getLocal:function(localName){
            return localforage.getItem(localName);
        },
        setLocal:function(localName,localValue){
            return localforage.setItem(localName,localValue);
        }
    }
});
