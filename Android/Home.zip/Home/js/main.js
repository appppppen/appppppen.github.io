//绑定全局函数
var kexAppJson = kexApp.kexJson;
kexAppJson.allRecommendList = undefined;
kexAppJson.allBooksDetails = {};
//用户数据采集全局定义
kexAppJson.action = [];
var configPath = 'http://114.214.164.24';
kexAppJson.config = {
	'params':{
		"visualFeatures": "Tags",
		"language": "en"
	},
	'apiKey' : "854db870b7e3444191562edb25ddd017",
	'apiUrl' : "https://api.projectoxford.ai/vision/v1.0/analyze?visualFeatures=Tags&language=zh",
	'imgSearch':configPath+'/api-gateway/search/courseware/image/',
	'audioSearch':configPath+'/api-gateway/search/courseware/audio/',
	'keyWordsSearch':configPath+'/api-gateway/search/courseware/keywords/',
	'contentSearch':configPath+'/api-gateway/search/courseware/content/',
	'classify':configPath+'/api-gateway/subject/list',
	'getRecommend':configPath+'/api-gateway/app/courseware/recommend',
	'getBooksDetailsFromAjax':configPath+'/api-gateway/app/courseware/',
	'getListsFromClass':configPath+'/api-gateway/app/courseware/list/subject/',
	'getTags':configPath+'/api-gateway/app/user/tag/subscribe/list',
	'getTagList':configPath+'/api-gateway/app/courseware/list/tag/',
	'getComment':configPath+'/api-gateway/app/courseware/comment/list/',
	'payModey':configPath+'/api-gateway/app/pay/buy',
	'upload':configPath+'/api-gateway/app/log/upload'
};

//用户数据采集每隔5分钟检查有多少数据，超过100组上传，清空用户数据
setInterval(function(){
	var length = kexAppJson.action.length;
	if(localStorage.getItem('user')){
		token = JSON.parse(localStorage.getItem('user')).token
	}
	if(length>=100&&token!=''){	
		var logs='';
		for(var i in kexAppJson.action){
			var log=JSON.stringify(kexAppJson.action[i])
			logs+=log+','
		}
		logs=logs.substring(0,logs.length-1);
		console.log(logs);
		console.log('['+logs+']');
		$.ajax({
			url:kexAppJson.config.upload,
			type:'POST',
			data:{
				token:token,
				logs:'['+logs+']'
			},
			dataType:"JSON",
			success:function(data){
				console.log(data)
				kexAppJson.action=[]
			},
			error:function(data){
				console.log(data)
			}
		})
	}else{
		
	}
},1000*60*5)
	
//写入所有书本
kexApp.kexJson.deleteNum = 0;
var token='';
kexAppJson.getAllBooksList = function(callback) {
	if(localStorage.getItem('user')){
		token = JSON.parse(localStorage.getItem('user')).token
	}
	if(token!=''){
		kexAppJson.allRecommendList = {};
		$.ajax({
			url:kexAppJson.config.getRecommend,
			type:'GET',
			data:{
				token:token
			},
			dataType:"JSON",
			success:function(data){
				console.log(data)
				var bjtj = data.recommend;
				var cpcx = data.discount;
				var cnxh = data.like;
				var bjtjList = {};
				for(var i=0;i<bjtj.length;i++){
					bjtjList[bjtj[i].id] = bjtj[i];
				}
				kexAppJson.allRecommendList.bjtj = bjtjList;

				var cpcxList = {};
				for( i=0;i<cpcx.length;i++){
					cpcxList[cpcx[i].id] = cpcx[i];
				}
				kexAppJson.allRecommendList.cpcx = cpcxList;

				var cnxhList = {};
				for( i=0;i<cnxh.length;i++){
					cnxhList[cnxh[i].id] = cnxh[i];
				}
				kexAppJson.allRecommendList.cnxh = cnxhList;
				localforage.setItem('AppBookCommendList',kexAppJson.allRecommendList);
				callback();
			},
			error:function(){
				localforage.getItem('AppBookCommendList').then(function(data){
					if(data){
						kexAppJson.allRecommendList = data;
						callback()
					}else{
						console.log('本地和ajax都获取不了')
					}
				})
			}
		});
	}
};
	//获取单本书
kexAppJson.getBookById = function(id,callback) {
	if(id){
		if(localStorage.getItem('user')){
			token = JSON.parse(localStorage.getItem('user')).token
		}
		if(kexAppJson.allBooksDetails.id){
			callback();
		}else if(token!=''){
			$.ajax({
				url:kexAppJson.config.getBooksDetailsFromAjax + id,
				type:'GET',
				data:{
					token:token
				},
				dataType:"JSON",
				success:function(data){
					kexAppJson.allBooksDetails[id] = data;
					callback();
					localforage.getItem('allBooksDetails').then(function(data){
						if(data){
							data[id] = kexAppJson.allBooksDetails[id];
							localforage.setItem('allBooksDetails',data);
						}else{
							localforage.setItem('allBooksDetails',kexAppJson.allBooksDetails);
						}
					});
				},
				error:function(){
					localforage.getItem('allBooksDetails').then(function(data){
						if(data[id]){
							kexAppJson.allBooksDetails[id] = data[id];
							callback();
						}else{
							console.log('本地缓存和ajax都无法获取数据');
						}
					})
				}
			})
		}

	}else{
		swal("缺少书籍ID，Bug需修复");
	}
}
//根据从书id获取从书下的书
kexAppJson.getChildrenBooksById = function(pid) {
		var parentBook = getBookById(pid);
		var childrenIds = parentBook.children;
		var books = [];
		for(var k in childrenIds) {
			books[k] = getBookById(childrenIds[k]);
		}
		return books;
	}
//获取我的书
kexAppJson.getMyBooks = function() {
		return myBooks;
}
//判断书籍的状态
kexAppJson.getBtnStatus = function(thisVersion) {

	if(thisVersion === 0) {
		return "获取";
	};
	if(thisVersion === 1) {
		return "更新";
	};
	if(thisVersion === 2) {
		return "打开";
	};
	if(thisVersion === 3) {
		return "下载中";
	};
	if(thisVersion === 4) {
		return "暂停中";
	};
	if(thisVersion === 5) {
		return "等待中";
	};
	if(thisVersion === 6) {
		return "解压中";
	};
	if(thisVersion === 7) {
		return "购买";
	}
};
//获取更新书籍的数据
var updateBooks = [];
//根据书籍状态触发的事件
kexAppJson.statusEvent = function(bookId, bookStatus, bookImg, bookName, bookNewTime, bookSize) {
	if(bookStatus === "获取" || bookStatus === "更新") {
		updateBooks.unshift({
			id: bookId,
			status: "下载中",
			img: bookImg,
			name: bookName,
			newTime: bookNewTime,
			size: bookSize
		})
	}
};
//创建本地缓存
kexAppJson.setLocal = function(ThisDetails) {
		var user = storedb("user").find();
		if(!ThisDetails.userPhone){ //标记用户电话号码
			ThisDetails.userPhone = user.phone;
		}
		if(ThisDetails){
			ThisDetails.localUser = 0;
		}
		if(thisDown === undefined) {
			var thisDown = {};
		}
		if(storedb("allDownload").find().length != 0) {
			var local = storedb("allDownload").find()
			var thisDown = local;
		}
	var localName = ThisDetails.id+user.phone;
		thisDown[localName] = ThisDetails;
		localStorage.setItem("allDownload", JSON.stringify(thisDown))
	}
	//添加下载列队
kexAppJson.pushLocal = function(downBookName) {
	var user = storedb("user").find();
		var local = storedb("allDownload").find();
	var localName = downBookName+user.phone;
		if(local.downBookName === undefined) {
			local.downBookName = [];
		}
		local.downBookName.push(localName);
		//去除重复
		local.downBookName = _.uniq(local.downBookName)
		localStorage.setItem("allDownload", JSON.stringify(local))
	}
	//更新缓存数据
kexAppJson.updateLocal = function(x, val, thisId) {
	var user = storedb("user").find();
		var allDownload = storedb("allDownload").find();
	var localName = thisId+user.phone;
		allDownload[localName][x] = val;
		kexAppJson.setLocal(allDownload[localName])
	}
	//删除缓存数据
kexAppJson.removeLocal = function(thisId) {
		var allDownload = storedb("allDownload").find();
	var user = storedb("user").find();
	var localName = thisId+user.phone;
		delete allDownload[localName];
		if(Object.keys(allDownload).length === 0) {
			storedb('allDownload').remove();
		} else {
			localStorage.setItem("allDownload", JSON.stringify(allDownload))
		}
	}
	//删除下载列队
kexAppJson.removeDownName = function(xName) {
	var user = storedb("user").find();
	var local = storedb("allDownload").find();
	var downName = local.downBookName;
	if(downName != undefined) {
		for(var i = 0; i < downName.length; i++) {
			var localName = xName+user.phone;
			if(downName[i] === localName) {
				downName.splice(i, 1);
				localStorage.setItem("allDownload", JSON.stringify(local))
			}
		}
	}
}

//页面关闭时
window.onbeforeunload = function() {
	var winLocal = storedb("allDownload").find();
	for(var l in winLocal) {
		if(winLocal[l].version === 3) {
			kexAppJson.updateLocal("version", 4, winLocal[l].id)
			kexAppJson.updateLocal("status", "暂停中", winLocal[l].id)
		}
	}
}()

//下载功能
function downloading(countDown, bookId) {
	if(document.getElementsByClassName("books").length === 0)
	{
		if(document.getElementsByClassName("selfbook").length === 0)
		{
			if(document.getElementsByClassName("downloading").length === 0)
			{
				if(document.getElementsByClassName("detail_container").length === 0)
				{
				} else {
					var ele = document.getElementsByClassName("detail_container")
				}
			} else {
				var ele = document.getElementsByClassName("downloading")
			}
		} else {
			var ele = document.getElementsByClassName("selfbook")
		}
	} else {
		var ele = document.getElementsByClassName("books")
	}
	var scope = angular.element(ele).scope();
	scope.changeValue(bookId, countDown);
	kexAppJson.updateLocal("downVal", countDown, bookId)
	if(countDown == 99) {
		//详情页的状态
		$(".detail_container .downIcon").addClass("hidden");
		$("#detailStatus").removeClass("hidden");
		$("#detailStatus").html("解压中");
		//丛书详情页
		var comBook = scope.books;
		if(comBook === undefined) {} else {
			for(var i = 0; i < comBook.length; i++) {
				if(comBook[i].id === bookId) {
					$($(".books dl")[i]).find(".downIcon").addClass("ng-hide");
					$($(".books dl")[i]).find("button").removeClass("ng-hide");
					$($(".books dl")[i]).find("button")[0].innerHTML = "解压中";
				}
			}
		}
	}
	if(countDown == 100) {
		kexAppJson.updateLocal("version", 2, bookId)
		kexAppJson.updateLocal("status", "打开", bookId)
		var newDate = new Date();
		var comTime = newDate.getTime(); //更新完成的排序根据
		var newYear = newDate.getFullYear();
		var newMonth = newDate.getMonth() + 1;
		var newDay = newDate.getDate();
		kexAppJson.updateLocal("newTime", newYear + "年" + newMonth + "月" + newDay + "日", bookId)
		kexAppJson.updateLocal("comTime", comTime, bookId);
		
		$(".detail_container .downIcon").addClass("hidden");
		$("#detailStatus").removeClass("hidden");
		$("#detailStatus").html("打开");

		//下载完成从列队中删除
		kexAppJson.removeDownName(bookId);
		
		var local = storedb("allDownload").find();
		var downName = local.downBookName;
		
		if(downName.length === 0) {
			$(".downloading").addClass("ng-hide")
			delete local.downBookName;
			localStorage.setItem("allDownload", JSON.stringify(local))
		}

		//更新页面下载完成
		var downComBook = scope.downloadings;
		if(downComBook === undefined) {} else {
			for(var i in downComBook) {
				if(downComBook[i].id === bookId) {
					scope.$apply(function() {
						downComBook[i].showItem = false;
					})
				}
			}
		}
		//书架单本书
		var downSelfBook = scope.selfBs;
		if(downSelfBook === undefined) {

		} else {
			for(var s in downSelfBook) {
				if(downSelfBook[s].id === bookId) {
					scope.$apply(function() {
						downSelfBook[s].downBtn = false;
						downSelfBook[s].btnText = false;
					})
				}
			}
		}
		//下载模块下载完成加到完成模块
		var downCombook = scope.completes;
		var localCboo = storedb("allDownload").find();
		if(downCombook === undefined) {

		} else {
			scope.$apply(function() {
				downCombook[bookId] = localCboo[bookId]
				scope.hasComplete = false
			})
		}
	}
}

function TipsRemain(bookname) {
	var local = storedb("allDownload").find();
	kexAppJson.updateLocal("status", "暂停中", bookname)
	kexAppJson.updateLocal("version", 4, bookname)
	swal("空间不足,已暂停" + local[bookname].name + "的下载");
}

function NeedUpdateBooks(hasbook) {
	if(hasbook == 1) {
		window.location.href = "index.html#/selfbook";
	} else {
		window.location.href = "index.html#/bookstack";
	}
}

function autoscreen() {
	if(localStorage["boolfrist"]=="true") {
		localStorage["boolfrist"]="false";
	}else{
		window.location.href = "uniwebview://changeAuto?name=ww";
	}
}
window.onload = function(){
	autoscreen();
}



//音量回调
function GetSoundVolumeReturn(msgstring){
var scope = angular.element(document.getElementById("wrapper")).scope();
}
//调用音频
function GetSoundReturn(msgstring){
	console.log(msgstring);
	getVideoFromDatabaseByTags(msgstring);
}
function getVideoFromDatabaseByTags(Tag) {
	var scope = angular.element(document.getElementById("wrapper")).scope();
	scope.$apply(function(){
		scope.tips = '正在查询中...';
	});
	$.ajax({
			url: kexAppJson.config.audioSearch+Tag,
			type: "GET",
			dataType: 'json',
			success:function(data){
				console.log(data);
				if(data.result == '没有任何结果'){
					scope.$apply(function(){
						scope.tips = '没有相关查询的内容';
						scope.isSearching = 0;
					});
				}else{
					var arr = data.result;
					localforage.setItem('searchArr', arr);
		            for(var i=0;i<arr.length;i++){
		                var obj = arr[i];
		                scope.lists.push(obj);
		            }
					scope.$apply(function(){
						scope.tips = '';         
						scope.isSearching = 0;
					});
				}
			},
			error:function(){
				var scope = angular.element(document.getElementById("wrapper")).scope();
				scope.$apply(function(){
					scope.tips = '查询失败';
					scope.isSearching = 0;
				});
			}
		})
}

//QQ登录反馈
function qqreturn(msgstring){
	var sb=new Array();
	sb=msgstring.split("|seedweet|");
	var openID=sb[0];
	var accessToken=sb[1];
	var expires=sb[2];
	$.ajax({
		url: 'http://114.214.164.24/api-gateway/app/auth/authLogin',
		type: "POST",
		data: {
			openId: openID,
			type:'QQ'
		},
		dataType: 'json',
		success:function(data){
			var msg=data.msg;
			localStorage.setItem("user", JSON.stringify(data.userInfo))
			var user=data.userInfo;
			var scope = angular.element(document.getElementById("wrapper")).scope();
			scope.logined=true;
			if(user.headImg){
				scope.userPic = user.headImg;
			}
			window.location.href="index.html#/userCenter";
		},
		error:function(data){
		alert("登录失败！");
		}
	})
}


//个推反馈
function getuimessage(stringmsg){
	window.location.href=stringmsg;
	window.localStorage.setItem("getuimsg",stringmsg);
}
function GetDeviceId(deviceId) {
	localStorage.setItem("deviceId", deviceId);
}
function GetCidReturn(sb){
	localStorage.setItem("clientid", sb);
}



function GetAlert(tip){
	alert("请在ipad的\"设置-隐私-相机\"中允许访问相机。");
}
//弃用函数，用于打开书籍时，书籍是否被破坏的反馈
function AlipayMessage(message) {
	if(message=="支付成功"){
		if(localStorage.getItem('user')){
			token = JSON.parse(localStorage.getItem('user')).token
		}
		$.ajax({
			url: 'http://114.214.164.24/api-gateway/app/user/account',
			type: "GET",
			data: {
				token:token
			},
			dataType: 'json',
			success:function(data){
				$('.capital span').text(data.coin);
				$('.recharge .recharge_num').val('');
				console.log(data)
			},
			error:function(data){
				console.log(data)
			}
		})
	}else{
	}
}

//弃用函数，用于打开书籍时，书籍是否被破坏的反馈
function Return(bookname) {
	var local = storedb("allDownload").find();
	swal({
			title: "Are you sure?",
			text: local[bookname].name + "已损坏！请删除后重新下载",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "删除并重新下载",
			cancelButtonText: "仅删除",
			closeOnConfirm: false,
			closeOnCancel: false
		},
		function(isConfirm) {
			if(isConfirm) {
				swal("开始下载", "你的文件已删除，正在重新下载", "success");
				var BookName = local[bookname].id;
				var Booksize = local[bookname].size;
				var downloadurl = local[bookname].fileMap;
				var realname  = local[bookname].file;
				window.location.href = "uniwebview://getordown?name=" + BookName 
				+ "&realname=" + realname 
				+ "&size=" + Booksize 
				+ "&downloadurl="+downloadurl; //更改后
			} else {
				swal("已删除！", "感谢您的使用", "success");
			}
		});
}
//验证码倒计时
var SetC;
function getCode_time(){
	var i=60;
    $('.getCode').css({'opacity':'0.6','pointer-events':'none'});
    SetC=setInterval(function(){
        if(i<0){
            clearInterval(self.SetC);
            $('.getCode').html('重新获取').css({'opacity':'1','pointer-events':'auto'});
            return false;
        }
        $('.getCode').html('&nbsp;'+i+'&nbsp;s');
        i--;
    },1000);
}
