angular
	.module("kexApp")
	.controller("uptagCtrl", ["$scope","$http",
		function($scope,$http) {
			var user = JSON.parse(localStorage.getItem("user"));
			var token=user.token,tabsevice=[],tagFlage=false,Tags='';
			var myTabs=[];
			$http({
				url:'http://114.214.164.24/api-gateway/tag/list/courseware',
				method:'GET',
			}).success(function(data){
				console.log(data);
				for(i in data){
					var tabs = {};
					tabs.tab=data[i].name;
					tabs.choosed=false;
					myTabs.push(tabs);
				}
			}).error(function(data){
				console.log(data);
			});
	  		$http({
			   url:$scope.serviceUrl+'user/tag/subscribe/list',
			   method:'GET',  
			   params:{
			   	    token:token
			   	}
	  		}).success(function (data) {
	  			var list=data.list
	  			tabsevice=[];
	  			for(var i=0;i<list.length;i++){
	  				tabsevice.push(list[i].tag)
	  			}
	  			for(var i=0;i<myTabs.length;i++){
	  				if($.inArray(myTabs[i].tab,tabsevice)!=-1){
	  					myTabs[i].choosed=true;
	  				}
	  			}
				$scope.myTabs=myTabs;
	  			console.log(data);
  			}).error(function(data){
	  			console.log(data);
	  		})
			$scope.choosedTab=function(ev){
				var el=ev.target;
				if(el.tagName=='SPAN'){
					var index=$(el).parent('div').parent('li').index();
				}else{
					var index=$(el).parent('li').index();
				}
				$scope.myTabs[index].choosed=!$scope.myTabs[index].choosed;
				tagFlage=true;
			}
			$scope.uptag=function(){
				//获取用户订阅
				if(tagFlage){
		  			//用户订阅标签与退订
		  			var Tags1='';
			  		for(var i=0;i<$scope.myTabs.length;i++){
			  			if($scope.myTabs[i].choosed){
			  				Tags+=$scope.myTabs[i].tab+',';
			  			}
			  		}
			  		Tags=Tags.substring(0,Tags.length-1);
			  		//发送到服务器
			  		$http({
					   url:$scope.serviceUrl+'user/tag/subscribe',
					   method:'POST',  
					   params:{
					   	     token:token,
					   	     tags:Tags
					   	}
			  		}).success(function (data) {
			  			console.log(data);
			  		}).error(function(data){
			  			console.log(data);
			  		})
			  		//发送到个推
					window.location.href = "uniwebview://SetTags?Tags="+Tags;
		  		}
				window.location.href="javascript:history.go(-1)"
			}
		}
	])