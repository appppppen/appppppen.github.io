angular
	.module("kexApp")
	.controller("selfCtrl", ["$scope",
		"$state",
		"$document",
		"radialIndicatorInstance",
		"httpService",
		'SweetAlert',
		'$rootScope',
		function($scope, $state, $document, radialIndicatorInstance, httpService, SweetAlert,$rootScope) {
			//downloadIcon
			$scope.downloadIcon = "./img/icon/download.png";
			//需要更新的数目
			$scope.updataNum = 0;
			//  从书弹出窗
			$scope.popW = window.innerWidth + "px";
			window.onresize = function() {
				$(".popup").css({width: window.innerWidth})
			}
			window.addEventListener("orientationchange", function() {
					//屏幕旋转后关闭弹窗
					$(".popup").addClass("ng-hide")
					setTimeout(function() {
						$(".popup").css({width: window.innerWidth})
					}, 500)
				})
				//获取图片高度
			setTimeout(function() {
					if($(".selfbook ul li")[0] === undefined) {
						return
					}
					kexApp.kexJson.imgH = $(".selfbook ul li")[0].offsetHeight + "px";
					window.addEventListener("orientationchange", function() {
						kexApp.kexJson.imgH = $(".selfbook ul li")[0].offsetHeight + "px";
					})
					window.onresize = function() {
						kexApp.kexJson.imgH = $(".selfbook ul li")[0].offsetHeight + "px";
					}
				}, 10)
				//我的书架
			var localSelfBook = {};
			var localCbook = {};
			$scope.ses = [];
			//加载数据
			selfBook = storedb("allDownload").find();
			var localUser = storedb("user").find();
			for(var se in selfBook) {
				if(se.indexOf(localUser.phone)<0){ continue;}
				if(selfBook[se].version === 3 ||
					selfBook[se].version === 4 ||
					selfBook[se].version === 5 ||
					selfBook[se].version === 2) {
					localSelfBook[se] = selfBook[se];
				}
			}
			$scope.selfBs = localSelfBook;
			var selfBs = $scope.selfBs;
			//单本初始加载状态
			for(var s in selfBs) {
				var BookName = selfBs[s].id;
				var size = selfBs[s].size;
				var downloadurl = selfBs[s].fileMap;
				var realname = selfBs[s].file;
				if(selfBs[s].version === 3) {
					//正在下载中
					window.location.href = "uniwebview://getordown?name=" + BookName + "&realname=" + realname + "&size=" + size + "&downloadurl=" + downloadurl; //更改后
					selfBs[s].downBtn = true;
					selfBs[s].isDown = true;
				};
				if(selfBs[s].version === 5) {
					//等待中
					window.location.href = "uniwebview://suspended?name=" + BookName + "&realname=" + realname; //暂停下载对应书籍
					selfBs[s].btnText = true;
					selfBs[s].status = "等待中";
				};
				if(selfBs[s].version === 4) {
					//暂停中
					window.location.href = "uniwebview://suspended?name=" + BookName + "&realname=" + realname; //暂停下载对应书籍
					selfBs[s].isDown = false;
					selfBs[s].downBtn = true;
				}
			}
			//跳转更新页面
			$scope.toUpdate = function() {
					if($scope.tabBtn === "选择") {
						$state.go("update")
					};
					//删除书本
					if($scope.tabBtn === "完成") {
						var selfBooks = $scope.selfBs;
						var name ="";
						var ID = "";
						var names = ' ';
						$(".choosed").addClass("ng-hide");
						//删除单本
						for(var b in selfBooks) {
							if(selfBooks[b].choosed === true) {
								var selfIndex = selfBooks[b].id;
								var localName = selfIndex+localUser.phone;
								name += selfIndex + "$$$";
								ID += selfBooks[b].file + ".";
								names += selfBooks[b].title+' ';
								//删除缓存
								kexAppJson.removeDownName(selfBooks[b].id);
								var local = storedb("allDownload").find();
								var downName = local.downBookName;
								if(storedb("allDownload").find().downBookName != undefined) {
									if(downName.length === 0) {
										delete local.downBookName;
										localStorage.setItem("allDownload", JSON.stringify(local))
									}
								}
								kexAppJson.removeLocal(selfBooks[b].id);
								selfBooks[b].choosed = false;
								selfBooks[b].showIcon = false;
							}
						}
						name += "0";
						window.location.href = "uniwebview://delete?name=" + name;
						SweetAlert.swal(names + "删除成功！");
						//还原状态
						$(".choosed.chooseIcon").addClass("ng-hide");
						kexApp.kexJson.deleteNum = 0;
					}
				}
				//从书弹出层
			$scope.popupIcon = "./img/icon/sanjiao@2x.png";
			//下载按钮
			$scope.downBtn = false;
			$scope.downAnimateIcon = "./img/icon/downOrStopIcon.png"
			$scope.indicatorOption = {
				radius: 25,
				percentage: true,
				barColor: "#90a200",
				displayNumber: false,
				barBgColor: "rgba(0,0,0,0.3)",
				initValue: 0,
				barWidth: 4
			}
			$scope.changeValue = function(bookId, val) {
					radialIndicatorInstance[bookId].animate(val);
				}
				//	点击书本
			$scope.popup = function($event) {
				//不在选择删除状态，是打开，不是从书，那么接打开
				var selfBookLocal = storedb("allDownload").find();
				//已经下载完成后，非选择状态下点击直接打开
				if($scope.tabBtn === "选择") {
					console.log("直接打开书籍")
					var unityBookName = this.selfB.id;
					var localName = unityBookName+localUser.phone;
					var unityBookrealname = this.selfB.file;
					$rootScope.details = selfBookLocal[localName];
					var mediaType = $rootScope.details.mediaType;
					//做判断 ，如果是图片，或者是视频做处理
					if(mediaType == 'image' || mediaType == 'video' || mediaType == 'audio') {
						$state.go('mediaShow')
					}else if(mediaType == 'html'){
						window.location.href = "uniwebview://changeLandscape?name=" + unityBookrealname;
							setTimeout(function(){
						window.location.href =unityBookrealname + ".html";
							},300);
					} else {
						window.location.href = "uniwebview://changeLandscape?name=" + unityBookrealname;
						$("#cover").addClass("loadImg");
						$("#dt").addClass("blackBg");
						setTimeout(function() {
							window.location.href = "./" + unityBookrealname + "/book/index.html?user=hhh";
						}, 300);
					}

					//记录当前时间，进行排序
					var nowDate = new Date();
					var newTime = nowDate.getTime();
					this.selfB.nowTime = newTime;
					var ThisId = this.selfB.id
					kexAppJson.updateLocal("nowTime", newTime, ThisId)
				};
				//选择状态下，再次点击更换状态
				if($scope.tabBtn === "完成") {
					this.selfB.showIcon = !this.selfB.showIcon;
					this.selfB.choosed = !this.selfB.choosed;
				}
			}

			//点击暂停或下载
			$scope.selfDownOrStop = function($event) {
					var selfName = this.selfB.id;
					var realname = this.selfB.file;
					var size = this.selfB.size;
					var downloadurl = this.selfB.fileMap;
					if($scope.tabBtn === "完成") {
						return
					}
					var localDownBook = storedb("allDownload").find();
					var downBookName = localDownBook.downBookName;
					//如果是下载状态
					if(this.selfB.isDown === true) {
						this.selfB.isDown = false;
						this.selfB.version = 4;
						this.selfB.status = "暂停中";
						kexAppJson.updateLocal("version", 4, this.selfB.id);
						//当前暂停，等待的第一个下载
						var BookName;
						var Bookrealname;
						var Booksize;
						window.location.href = "uniwebview://suspended?name=" + selfName 
						+ "&realname=" + realname;
					} else if(this.selfB.isDown === false) {
						//变为下载状态
						this.selfB.isDown = true;
						kexAppJson.updateLocal("version", 3, this.selfB.id)
						//没有下载的，当前变为下载
						this.selfB.status = "下载中";
						this.selfB.btnText = false;
						this.selfB.downBtn = true;
						this.selfB.version = 3;
						//更改缓存
						kexAppJson.updateLocal("version", 3, this.selfB.id)
						kexAppJson.updateLocal("status", "下载中", this.selfB.id)
						window.location.href = "uniwebview://getordown?name=" + selfName 
						+ "&size=" + size 
						+ "&downloadurl=" + downloadurl; //更改后
					}
				}
				//关闭弹出层
			$(function() {
				FastClick.attach(document.body);
			});
			//选择按钮
			$scope.tabBtn = "选择";
			$scope.chooseShow = false;
			$scope.choose = function() {
					if($scope.tabBtn === "选择") {
						$scope.tabBtn = "完成";
						$scope.downloadIcon = "./img/icon/del.png";
					} else if($scope.tabBtn === "完成") {
						$scope.tabBtn = "选择";
						$scope.downloadIcon = "./img/icon/download.png";
						//还原状态
						$(".chooseIcon").addClass("ng-hide");
						var selfBo = $scope.selfBs;
						for(var s in selfBo) {
							selfBo[s].choosed = false;
							selfBo[s].showIcon = false;
						}
						kexApp.kexJson.deleteNum = 0;
					}
					$scope.chooseShow = !$scope.chooseShow;
				}
			//从书的选择
			$scope.BookShowChoose = false;
			$scope.popupBtn = false;
			$scope.chooseBooks = "./img/icon/choooseIcon@2x.png";
		}
])