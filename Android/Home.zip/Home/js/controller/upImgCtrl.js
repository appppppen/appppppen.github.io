angular
	.module("kexApp")
	.controller("upImgCtrl", ["$scope","$http","$rootScope",
		function($scope,$http,$rootScope) {
			var bgW,bgH,fileFlag=false,mx,my,pw,ph,LS,zoom=1,touchX,touchY,touchX2,touchY2;
			
			var userPic=$rootScope.userPic
		    var winH=window.innerHeight;
		    var winW=window.innerWidth;
		    var thumbBox=$('.thumbBox');
		    var imageBox=$('.imageBox');
		    var header_top=106;
		    imageBox.height(winH-header_top);
		    imageBox.css('background-color','rgb(0,0,0,0.6)')
		    thumbBox.height((winH-header_top)/2).width((winH-header_top)/2).css({marginTop:(winH-header_top-thumbBox.height())/2,marginLeft:(winW-thumbBox.width())/2,borderRadius:(thumbBox.width())/2});
		    var mT=parseInt(thumbBox.css('margin-top'))
            var mL=parseInt(thumbBox.css('margin-left'))
            var boxHW=(winH-header_top)/2;
           
            var image_bg = new Image();
		    var cropper = cropbox();
		    
		    window.onresize=function(){
		    	winH=window.innerHeight;
		    	winW=window.innerWidth;
		    	imageBox.height(winH-header_top)
		    	thumbBox.height((winH-header_top)/2).width((winH-header_top)/2).css({marginTop:(winH-header_top-thumbBox.height())/2,marginLeft:(winW-thumbBox.width())/2,borderRadius:(thumbBox.width())/2});
		        mT=parseInt(thumbBox.css('margin-top'))
                mL=parseInt(thumbBox.css('margin-left'))
                boxHW=(winH-header_top)/2
		        setBackground();
		    }
			
			//点击获得图片
			$scope.uploadFile=function(){
				$('#upload-file').click();
				var aa="AA";
				window.location.href = "uniwebview://getAlert?name=" + aa;
			}
			$('#upload-file').on('change', function(){
				var files=this.files[0];
				if(!/image\/\w+/.test(files.type)){
		            return false;
		       	}
                var windowURL = window.URL || window.webkitURL;
				var dataURL = windowURL.createObjectURL(files);
		        userPic = dataURL;
		        fileFlag=true;
				cropper = cropbox();
			})
			
			//加载背景图
		    function cropbox(){
	            image_bg.src = userPic;
		        image_bg.onload = function() {
		            setBackground();
		            if(fileFlag){
		            	imageBox.bind('touchstart', imgTouchStart);
			            imageBox.bind('touchmove', imgTouchMove);
			            $(window).bind('touchend', imgTouchEnd);
			            $('.register').show();
		            }
		        }
		    }
			
			//背景图定位
		    function setBackground(){
	            bgW =  parseInt(image_bg.width);
	            bgH =  parseInt(image_bg.height);
	            if(image_bg.width>=image_bg.height){
	        		bgW=(thumbBox.height()/image_bg.height)*image_bg.width+2
	        		bgH=thumbBox.height()+2
	        	}else{
	        		bgW=thumbBox.width()+2
	        		bgH=(thumbBox.width()/image_bg.width)*image_bg.height+2
	        	}
	        	pw = (imageBox.width() - bgW) / 2+1;
	            ph = (imageBox.height() - bgH) / 2+1;
	            imageBox.css({
	                'background-image': 'url(' + image_bg.src + ')',
	                'background-size': bgW +'px ' + bgH + 'px',
	                'background-position': pw + 'px ' + ph + 'px',
	                'background-repeat': 'no-repeat'});
	        }
		    
		    //背景图拖动、缩放
	        function imgTouchStart(e){
	            touchX = event.touches[0].clientX;
	            touchY = event.touches[0].clientY;
	            if(event.touches.length>=2){
	            	touchX2 = event.touches[1].clientX;
	            	touchY2 = event.touches[1].clientY;
	            	LS=Math.sqrt(Math.pow(touchX-touchX2,2)+Math.pow(touchY-touchY2,2))
	            }
	        }
	        function imgTouchMove(e){
            	if(event.touches.length==2){
            		var L=Math.sqrt(Math.pow(event.touches[1].clientX-event.touches[0].clientX,2)+Math.pow(event.touches[1].clientY-event.touches[0].clientY,2))
            		if(L/LS>1){
            			zoom=1.03
            		}else if(L/LS==1){
            			zoom=1
            		}else{
            			zoom=0.95
            		}
            		bgW*=zoom;
            		bgH*=zoom;
            		if(bgW<=thumbBox.width()){
            			bgW=thumbBox.width()+2
        				bgH=(thumbBox.width()/image_bg.width)*image_bg.height+2	
            		}
            		if(bgH<=thumbBox.width()){
            			bgW=(thumbBox.height()/image_bg.height)*image_bg.width+2
        				bgH=thumbBox.height()+2
            		}
            		pw = (imageBox.width() - bgW) / 2+1;
            		ph = (imageBox.height() - bgH) / 2+1;
            		imageBox.css({
            			'background-size': bgW +'px ' + bgH + 'px',
	                	'background-position': pw +'px ' + ph + 'px'
	                });
            	}else if(event.touches.length==1){
            		mx = event.touches[0].clientX - touchX;
	                my = event.touches[0].clientY - touchY;
	                if(ph+my>=mT){
	                	ph=mT-my
	                }
	                if(pw+mx>=mL){
	                	pw=mL-mx
	                }
	                if(pw+mx+bgW<=boxHW+mL+2){
	                	pw=boxHW+mL-bgW+2-mx
	                }
	                if(ph+my+bgH<=boxHW+mT+2){
	                	ph=boxHW+mT-bgH+2-my
	                } 
	                imageBox.css({
	                	'background-position': (pw+mx) +'px ' + (ph+my) + 'px'
	                });
            	}
	        }
	        function imgTouchEnd(e){
	            pw+=mx
	            ph+=my
	        }
		    
		     //裁剪
		    function getDataURL(){
                var width = thumbBox.width();
                var height = thumbBox.height();
                var canvas = document.createElement("canvas");
                var dim = imageBox.css('background-position').split(' ');
                var size = imageBox.css('background-size').split(' ');
                var dx = parseInt(dim[0]) - imageBox.width()/2 + width/2;
                var dy = parseInt(dim[1]) - imageBox.height()/2 + height/2;
                var dw = parseInt(size[0]);
                var dh = parseInt(size[1]);
                var sh = parseInt(image_bg.height);
                var sw = parseInt(image_bg.width);
                
                canvas.width = width;
                canvas.height = height;
                var context = canvas.getContext("2d");
                context.drawImage(image_bg, 0, 0, sw, sh, dx, dy, dw, dh);
                var imageData = canvas.toDataURL('image/png');
                return imageData;
            }
		    
			//头像发送参数定义
			var user=JSON.parse(localStorage.getItem("user"))
			var token=user.token
			var urllib,Buffer,OSS2,STS,region,bucket,path;
			
			//base64转file
			function dataURLtoFile(dataurl, filename) {
			    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
			        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
			    while(n--){
			        u8arr[n] = bstr.charCodeAt(n);
			    }
			    return new File([u8arr], filename, {type:mime});
			}
			
			//向阿里云OSS发送图片
			$scope.btnCrop=function(){
				var img_b64 = getDataURL();
				
				var file_name=(new Date()).getTime()+''+(Math.random()*Math.random())+'.png'
				console.log(file_name)
				
				file = dataURLtoFile(img_b64, file_name);
				console.log(file);
				
				urllib = OSS.urllib;
				Buffer = OSS.Buffer;
				OSS2 = OSS.Wrapper;
				STS = OSS2.STS;
				$http({
				   url:$scope.serviceUrl+'user/headImage/path',
				   method:'GET',  
				   params:{token:token}
		  		}).success(function (data) {
		  			region=data.region;
		  			bucket=data.bucketName;
		  			path=data.path;
		  			$http({
					   url:$scope.serviceUrl+'auth/user/storage/credential',
					   method:'GET',  
					   params:{token:token}
			  		}).success(function (data) {
			  			creds=data.credential;
			  			var applyTokenDo = function (func) {
						    var client = new OSS2({
							    region: region,
							    accessKeyId: creds.accessKeyId,
							    accessKeySecret: creds.accessKeySecret,
							    stsToken: creds.securityToken,
							    bucket: bucket
							});
							return func(client);
						};
						var uploadFile = function (client) {
						  var key = path+file_name;
						  return client.multipartUpload(key, file, {
						    
						  }).then(function (result) {
							    var headImg=result.res.requestUrls[0];
							    headImg=headImg.split('?')[0]
							    console.log(headImg)
							    $http({
								   url:$scope.serviceUrl+'auth/user/info/update',
								   method:'POST', 
								   params:{
								   	    token:token,
								   	    headImg:headImg
								   	}
						  		}).success(function (data) {
						  			$rootScope.userPic=img_b64
						  			console.log(data);
						  			user.headImg=headImg
						  			localStorage.setItem("user", JSON.stringify(user));
						  			swal('保存成功！')
						  		}).error(function(data){
						  			console.log(data);
						  			swal('保存失败！')
						  		})
						  });
						};
						applyTokenDo(uploadFile);
			  		}).error(function(data){
			  			var msg=data.msg;
			  			console.log(msg);
			  			swal('保存失败！')
			  		})
		  		}).error(function(data){
		  			var msg=data.msg;
		  			console.log(msg);
		  			swal('保存失败！')
		  		})
		  		window.location.href="index.html#/userCenter";
			}
		}
	])
