angular
	.module("kexApp")
	.controller("circumCtrl", ["$scope","$rootScope",
		function($scope,$rootScope) {
			$scope.leftIcon = "./img/icon/left.png";
			if($rootScope.details){
				localStorage.setItem("details", JSON.stringify($rootScope.details))
			}
			details=JSON.parse(localStorage.getItem("details"))
			$scope.circumImg = details.img;
			$scope.circumName = details.name;
			$scope.circumType = details.type;
			$scope.buyWay = "淘宝购买";
			$scope.detddW = (window.innerWidth - 120) + "px";
			window.onresize = function() {
					var ddW = window.innerWidth - 120;
					$(".circum_head dd").css({
						width: ddW
					})
				}
			window.onorientationchange = function(){
				var ddW = window.innerWidth - 120;
					$(".circum_head dd").css({
						width: ddW
					})
			}
			$scope.detailImgs =details.detailImage;
			$scope.circumText = details.info;
			$scope.texts = details.texts;
			$scope.buy_way=function(){
				window.location.href = "uniwebview://OpenUrl?url=ssss";
				setTimeout(function(){window.location.href=details.url;},50)
			}
		}
	])