angular
	.module("kexApp")
	.controller("registerCtrl", ["$scope","$http",
		function($scope,$http) {
			clearInterval(SetC);
            $('.getCode').html('获取验证码').css({'opacity':'1','pointer-events':'auto'});
            $scope.smsId='';
			$scope.getValidate=function(){
				getCode_time();
				$http({
				   url:$scope.serviceUrl+'user/sms/send',
				   method:'POST',  
				   params:{phone:$scope.phone}
		  		}).success(function (data) {
		  			var sms=data.sms;
		  			$scope.smsId=sms.sid; 
		  			console.log($scope.smsId)
		  		}).error(function(data){
		  			var msg=data.msg;
		  			swal(msg);
		  			console.log(msg);
		  		})
			}
			$scope.register=function(){
				if($scope.myForm.$valid&&$scope.password.length>=6&&$scope.password.length<=16&&$scope.smsId!=''){
					$http({
					   url:$scope.serviceUrl+'user/register',
					   method:'POST',  
					   params:{
						   	phone:$scope.phone,
						   	smsId:$scope.smsId,
						   	code:$scope.code,
						   	password:$scope.password,
						   	password_confirm:$scope.password_confirm
					    }
			  		}).success(function (data) {
			  			var msg=data.msg;
			  			console.log(msg);
			  			//用户数据采-用户注册
			  			var register = {};
						register.startTime = String(new Date().getTime());
						register.contentType = 'register';
						register.contentId = $scope.phone;
						register.device = localStorage.getItem("deviceId");
						register.endTime = String(new Date().getTime());
						kexAppJson.action.push(register);
						swal('注册成功')
			  			window.location.href='index.html#/login';
			  		}).error(function(data){
			  			var msg=data.msg;
			  			swal(msg);
			  			console.log(msg);
			  		})
			  	}else{
			  		if($scope.myForm.phone.$error.required){
						swal('请输入手机号')
					}else if($scope.myForm.phone.$error.pattern){
						swal('手机号不正确')
					}else if($scope.myForm.password.$error.required){
						swal('请输入密码(6-16位字母或数字)')
					}else if($scope.myForm.password.$error.pattern){
						swal('密码不能包含特殊字符')
					}else if($scope.password.length<6 || $scope.password.length>16){
						swal('密码应为6-16位字母或数字')
					}else if($scope.myForm.password_confirm.$error.required||$scope.password!=$scope.password_confirm){
						swal('两次密码不一致')
					}else if($scope.myForm.code.$error.required){
						swal('请输入验证码')
					}else if($scope.smsId==''){
						swal('验证码错误')
					}
			  	}	
			}
		}
	])