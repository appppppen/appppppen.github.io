angular
    .module('kexApp')
    .controller('myFocusCtrl',['$scope','httpService','$state','$rootScope',
        function($scope,httpService,$state,$rootScope){

            $scope.nowLists =[];
            $scope.listTitle =[];
            $scope.tagNames = [];
            $scope.leftIcon = './img/icon/left.png';
            $scope.order_width = (window.innerWidth - 150) + "px";

            //更新dd的宽度
            $scope.stddw = (window.innerWidth - 110) + "px";
            window.onresize = function() {
                var stddw = window.innerWidth - 110;
                $(".stack-list dl dd").css({
                    width: stddw
                })
            };
            window.onorientationchange = function() {
                var stddw = window.innerWidth - 110;
                $(".stack-list dl dd").css({
                    width: stddw
                })
            };

            /*if(kexApp.kexJson.tagList){
                $scope.nowLists = kexApp.kexJson.tagList;
                $scope.tagNames = kexApp.kexJson.tagListName;
            }else{*/
                var user = JSON.parse(localStorage.getItem("user"));
                var token = user.token;
                if(!token){ console.log('没有token值');return; }
                var res = httpService.getTags(token);
                res.then(function(data){
                    var list = data.data.list;
                    kexApp.kexJson.tagList = $scope.listTitle = list;
                    kexApp.kexJson.tagListName = [];

                    for(var i=0;i<list.length;i++){
                        var tagName = list[i]['tag'];
                        getHttp(token,tagName,tagName);
                    }

                    function getHttp(token,tagName){
                        httpService.getTagList(token,tagName).then(function(data){
                            var totolCount = data.data.totalCount;
                            var lists = [];
                            if(totolCount!=0){
                                var listt = data.data.result;
                                for(var j=0;j<listt.length;j++){
                                    listt[j]['type'] = listt[j]['tag'].split(',');
                                    lists.push(listt[j]);
                                }
                                $scope.nowLists.push(lists);
                                kexApp.kexJson.tagList =  $scope.nowLists;


                                $scope.tagNames.push(tagName);
                                kexApp.kexJson.tagListName = $scope.tagNames;
                                console.log($scope.tagNames[0])
                            }
                        });
                    }
                },function(){
                    console.log('获取不到数据')
                });

           /* }*/
            $scope.toThisDet = function() {
                //获取素材的id
                localStorage.setItem("bookId", this.stackDl.id);
                var go ;
                if(this.stackDl.isSeries){
                    go = 'books';
                    $rootScope.bookssDes = this.stackDl.description;
                    $rootScope.bookssName = this.stackDl.title;
                }else{
                    go = 'details';
                }
                //传递当前书本的id
                $state.go(go, {
                    detailId: this.stackDl.id,
                    booksId: this.stackDl.id
                })
            };


     }
]);