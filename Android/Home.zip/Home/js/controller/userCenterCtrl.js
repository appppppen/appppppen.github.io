angular
	.module("kexApp")
	.controller("userCenterCtrl", ["$scope", "$http","$rootScope",
		function($scope, $http,$rootScope) {
			var user = JSON.parse(localStorage.getItem("user"));
			var token=user.token;
			if(user.nickName){
				$scope.nickName=user.nickName;
			}else{
				$scope.nickName='未填写';
			}
			if(user.sex){
				$scope.sex = user.sex;

			}else{
				$scope.sex='未填写'
			}
			if(user.age){
				$scope.age=user.age
			}else{
				$scope.age='未填写'
			}
			if(user.address){
				$scope.address=user.address
			}else{
				$scope.address='未填写'
			}
			$scope.logout = function() {
				var token=user.token;
				//用户数据采-用户登出
				var logout = {};
				logout.startTime = String(new Date().getTime());
				logout.contentType = 'logout';
				logout.contentId = token;
				logout.device = localStorage.getItem("deviceId");
				kexAppJson.action.push(logout);
				var logs='';
				for(var i in kexAppJson.action){
					var log=JSON.stringify(kexAppJson.action[i])
					logs+=log+','
				}
				logs=logs.substring(0,logs.length-1);
			    if(user){
			    	setTimeout(function(){
			    		$http({
				    		url: $scope.serviceUrl+'log/upload',
				    		method: 'POST',
				    		params:{
				    			token:token,
				    			logs:'['+logs+']'
				    		}
				    	}).success(function(data){
				    		var msg = data.msg;
				    		console.log(msg);			    	
							$http({
								url: $scope.serviceUrl+'auth/logout',
								method: 'POST',
								params:{token:token}
							}).success(function(data) {
								var msg = data.msg;
								console.log(msg);
								kexAppJson.action=[];
							}).error(function(data) {
								var msg = data.msg;
								console.log(msg);
							});
						}).error(function(data){
							var msg = data.msg;
							console.log(msg);
						})
						localStorage.removeItem("user");
						localforage.setItem("AppBookCommendList",'');
						$rootScope.logined = false;
						$rootScope.userPic = './img/images/user1.png';										
						window.location.href = "index.html#/login";
			    	},100)
			  	}
			}
			$scope.to_bookstack=function(){
				window.location.href="index.html#/bookstack"
			}
			var input_flag=false;
			$scope.focusIn=function(ev){
				var el=ev.target;
				if(ev.target.value=='未填写'){
					ev.target.value=''
				}
				$(el).change(function(){
					input_flag=true;
					return false;
				})
			};
			$scope.editUser=function(ev){
				var keys=ev.target.name
				var values=ev.target.value;
				//用户信息
				if((keys=='age'&&(isNaN(values)||values<0||values>100||values-parseInt(values)!=0))||
				values.length==0){
			        ev.target.value=user[keys]==null?'未填写':user[keys]
					input_flag=false;
			        return false;
			   	}
				if(keys=='sex'){
					values=values=='男'?'女':'男';
				}
				if(input_flag||keys=='sex'){
					input_flag=false;
					var params={}
					params.token=token;
					params[keys]=values;
					$http({
					   url:$scope.serviceUrl+'auth/user/info/update',
					   method:'POST', 
					   params:params
			  		}).success(function (data) {
			  			console.log(data);
			  			user[keys]=values;
			  			localStorage.setItem("user", JSON.stringify(user));
			  		}).error(function(data){
			  			console.log(data);
			  		})
				}
			}
		}
	])