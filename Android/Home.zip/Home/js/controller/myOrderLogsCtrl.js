angular
	.module("kexApp")
	.controller("myOrderLogsCtrl", ["$scope","$http",
		function($scope,$http) {
			var user = JSON.parse(localStorage.getItem("user"));
			console.log(user);
			if(user) {
			 	var token = user.token;
			 	$http({
			 		url: $scope.serviceUrl + 'user/order/logs',
			 		method: 'GET',
			 		params: {token: token}
			 	}).success(function(data) {
			 		var msg = data.msg;
			 		console.log(data);
			 		$scope.orderList=data.list
			 		console.log($scope.orderList)
			 	}).error(function(data) {
			 		var msg = data.msg;
			 		console.log(msg);
			 	})
			}
		}
	])