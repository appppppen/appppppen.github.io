angular
    .module('kexApp')
    .controller('classifyBooksCtr',['$scope','$state', '$stateParams','httpService','$rootScope',
    function($scope,$state,$stateParams,httpService,$rootScope){

        var classifyType = $.trim($stateParams.type);
        $scope.booksType = classifyType;

        if(kexAppJson.classifyList){
            for(var k=0;k<kexAppJson.classifyList.length;k++){
                if(kexAppJson.classifyList[k].type == classifyType){
                    $scope.booksType = kexAppJson.classifyList[k].name;
                }
            }
        }

        $scope.nowLists = [];
        $scope.leftIcon = './img/icon/left.png';
        $scope.stddw = (window.innerWidth - 130) + "px";
        window.onresize = function() {
            var stddw = window.innerWidth - 130;
            $(".stack-list dl dd").css({
                width: stddw
            })
        };
        window.onorientationchange = function() {
            var stddw = window.innerWidth - 130;
            $(".stack-list dl dd").css({
                width: stddw
            })
        };

        var getList = httpService.getListsFromSub(classifyType);
        getList.then(function(data){
            console.log(data)
            if(data.data.totalCount){
                var childBook,nowObj,book,arr,i;
				 $scope.show = true;
                var shuju = data.data.result;
                for( var key in shuju){
                    book = shuju[key];
                    if(book['tag']){
                        arr = book['tag'].split(',');
                        book['type'] = arr;
                    }
                    nowObj = book;
                    $scope.nowLists.unshift(nowObj);

                }
            }else{
                console.log('没有数据');
                $scope.show = false;
                $scope.noBook="暂无图书，敬请期待！"
            }
        },function(){
            console.log('请求错误');
        });

        $scope.toThisDet = function() {
            //获取素材的id
            localStorage.setItem("bookId", this.stackDl.id);
            //传递当前书本的id
            $state.go('details', {
                detailId: this.stackDl.id
            })
        };
    }
])