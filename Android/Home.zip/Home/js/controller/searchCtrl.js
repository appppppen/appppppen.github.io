angular
	.module('kexApp')
	.controller('searchCtrl', ['$scope', 'httpService', '$rootScope', '$sce', '$state',
		function($scope, httpService, $rootScope, $sce, $state) {
			$scope.leftIcon = './img/icon/left.png';
			$scope.placeHouder = '请输入查找内容';
			$scope.inputText = '';
			$rootScope.tips = '';
			$rootScope.isSearching = 0;
			$rootScope.lists = [];
			$rootScope.sce = $sce;
			$scope.videoCtr = function(obj, list) {
				if(obj.target.paused) {
					obj.target.play();
					list.imgShow = true;
				} else {
					obj.target.pause();
					list.imgShow = false;
				}
			};

			//获取desc_content的宽度
			$scope.stddw = (window.innerWidth - 140) + "px";
			window.onresize = function() {
				var ddW = window.innerWidth - 140;
				$(".desc_content").css({
					width: ddW
				})
			};
			window.onorientationchange = function() {
				var ddW = window.innerWidth - 140;
				$(".desc_content").css({
					width: ddW
				})
			};
			//判断有没有缓存
			localforage.getItem('searchArr').then(function(data) {
				$rootScope.$apply(function(){
					console.log(data);
					if(data) {
						arr = data;
						for(var i = 0; i < arr.length; i++) {
								var obj = arr[i];
								$rootScope.lists.push(obj);
						}
					} else {
						console.log('本地没有缓存');
					}
				})
				
				})
			$scope.back = function(){
				localforage.setItem('searchArr', '');
				window.location.href="javascript:history.go(-1)";
			}
				//判断当前书本
			$scope.toThisDet = function() {
				//用户数据采-获取素材的id					
				$rootScope.watched = this.list.id;
				$rootScope.startTime = String(new Date().getTime());

				//传递当前书本的id
				$state.go('details', {
					detailId: this.list.id
				})
			};

			//文本搜索
			$scope.textSearch = function() {
				if($rootScope.isSearching) {				
					$rootScope.tips = '正在查询中...';
					return;
				}
				$rootScope.tips = '';
				$rootScope.lists = [];
				$rootScope.isSearching = 1;
				//用户数据采-用户搜索
				var book_search = {};
				book_search.startTime = String(new Date().getTime());
				book_search.contentType = 'book_search';
				book_search.contentId = $scope.inputText;
				book_search.device = localStorage.getItem("deviceId");
				kexAppJson.action.push(book_search);
				if($.trim($scope.inputText)) {
					var tags = $scope.inputText;
					var res = httpService.getContent(tags);
					res.then(function(data) {
						console.log(data)
						$rootScope.tips = '';
						if(!data.data.totalCount) {
							$rootScope.tips = '没有相关查询的内容';
							$rootScope.isSearching = 0;
						} else {
							var arr = data.data.result;
							localforage.setItem('searchArr', arr);
							//TODO
							for(var i = 0; i < arr.length; i++) {
								var obj = arr[i];
								$rootScope.lists.push(obj);
							}
							$rootScope.isSearching = 0;
						}
						$rootScope.isSearching = 0;
					}, function() {
						$rootScope.tips = '未搜索到相关图书';
						$rootScope.isSearching = 0;
					})
				}
			};
			//图片搜索
			$scope.imgSearch = function(files) {
				if($rootScope.isSearching) {
					$rootScope.tips = '正在查询中...';
					return;
				}
				$rootScope.lists = [];
				$rootScope.tips = '正在查询中...';
				$rootScope.isSearching = 1;
				var url = window.URL.createObjectURL(files[0]);
				//用户数据采-用户搜索
				var book_search = {};
				book_search.startTime = String(new Date().getTime());
				book_search.contentType = 'book_search';
				book_search.contentId = url;
				book_search.device = localStorage.getItem("deviceId");
				kexAppJson.action.push(book_search);
				if(url) {
					var getTags = httpService.getImages(files[0]);
					getTags.then(function(data) { // 成功
						var tags = data.data.tags,
							tagString;
						if(tags.length) {
							for(var i = 0; i < tags.length; i++) {
								i == 0 ?
									tagString = tags[i].name :
									tagString += ("," + tags[i].name)
							}
							var getRes = httpService.getImagesFromDatabaseByTags(tagString);
							getRes.then(function(data) {
								$rootScope.tips = '';
								if(!data.data.totalCount) {
									$rootScope.tips = '没有相关查询的内容';
									$rootScope.isSearching = 0;
								} else {
									var arr = data.data.result;
									localforage.setItem('searchArr', arr);
									//TODO
									for(var i = 0; i < arr.length; i++) {
										var obj = arr[i];
										$rootScope.lists.push(obj);
									}
									$rootScope.isSearching = 0;
								}
							}, function() {
								$rootScope.tips = '未搜索到相关图书';
								$rootScope.isSearching = 0;
							})

						} else {
							$rootScope.tips = '没有相关查询的内容';
							$rootScope.isSearching = 0;
						}

					}, function() {
						$rootScope.tips = '未搜索到相关图书';
						$rootScope.isSearching = 0;
					});
				}
			};
		}

	]);
//语音搜索
kexApp.directive('voiceDire', function($rootScope) {
	return {
		restrict: 'C',
		link: function(scope, element) {
			element.bind('touchstart', function() {
				$rootScope.$apply(function(){
					$rootScope.tips = '正在录音中...';
				})
				$rootScope.lists = [];
				$rootScope.isSearching = 1;
				$(element).css('background-color', '#b2b2b2');
				$('.iocnShow').css('display','block');
//				$('.spinner').css('display','block');
				window.location.href = "uniwebview://StartRecognize?Get=s";
			});
			element.bind('touchend', function() {
				if($rootScope.isSearching) {
					window.location.href = "uniwebview://Cancel?Get=s";
					$rootScope.isSearching = 0;
					$rootScope.$apply(function(){
						$rootScope.tips = '查询完毕';
					});
					$(element).css('background-color', 'transparent');
					$('.iocnShow').css('display','none');
//					$('.spinner').css('display','none');
				}
				$(element).css('background-color', 'transparent');
				$('.iocnShow').css('display','none');
//				$('.spinner').css('display','none');
			})
		}
	}

})
