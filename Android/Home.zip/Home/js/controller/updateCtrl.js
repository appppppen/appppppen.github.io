angular
	.module("kexApp")
	.controller("updateCtrl", ["$scope",
		"radialIndicatorInstance",
		"$http",
		"httpService",
		'SweetAlert',
		'$state',
		'$rootScope',
		function($scope, radialIndicatorInstance, $http, httpService,SweetAlert,$state,$rootScope) {
			$scope.leftIcon = "./img/icon/left.png";
			$scope.downAnimateIcon = "./img/icon/downOrStopIcon.png";
			$scope.upddw = (window.innerWidth - 100) + "px";
			$scope.upddw = (window.innerWidth - 95) + "px";
			window.onresize = function() {
				var upddw = window.innerWidth - 95;
				$(".downloading dl dd").css({
					width: upddw
				})
			}
			window.onorientationchange = function() {
				var upddw = window.innerWidth - 95;
				$(".downloading dl dd").css({
					width: upddw
				})
			}
			var startX;
			$(".downloading")
				.on("touchstart", "dl", function(e) {
					$(this).find(".del").css({
						right: "-130px"
					})
					startX = e.originalEvent.targetTouches[0].pageX;
				})
				.on("touchmove", "dl", function(e) {
					var moveX = e.originalEvent.targetTouches[0].pageX - startX + 130;
					var delBtnRight = -Math.min(Math.max(10, moveX), 130)
					e.currentTarget.children[2].style.right = delBtnRight + "px"
				})
				.on("touchend", "dl", function(e) {
					var crisis = parseInt(e.currentTarget.children[2].style.right);
					var newDelRight;
					if(crisis > -60) {
						newDelRight = "-10px";
					} else if(crisis < -60) {
						newDelRight = "-130px";
					} else {}
					$(e.currentTarget.children[2]).animate({
						right: newDelRight
					}, 200)
				})
			//正在下载,取本地缓存的所有正在下载的数据
			$scope.downloadings = {};
			$scope.completes = {};
			var allDownBooks = storedb("allDownload").find();
			var localUser = storedb("user").find();
			for(var b in allDownBooks) {
				//数据加到正在下载模块
				if(b.indexOf(localUser.phone) <0){ continue;}
				if(allDownBooks[b].version === 3 || allDownBooks[b].version === 4 || allDownBooks[b].version === 5) {
					$scope.downloadings[b] = allDownBooks[b];
					$scope.downloadings[b].showItem = true;
				};
				//数据加到下载完成模块
				if(allDownBooks[b].version === 2 && allDownBooks[b].status === "打开") {
					$scope.completes[b] = allDownBooks[b];
				}
			}

			//点击更新按钮
			$scope.toUpateBook = function() {
					var updateId = this.updateDl.id ;
					var localName = updateId+ localUser.phone;
					//当前的在缓存内数据更改为下载，加入下载列队
					//视觉的隐藏
					this.updateShow = false;
					$scope.downloadings[localName] = $scope.updateDls[localName];
					var updateLength = Object.keys($scope.updateDls).length;
					var downLength = Object.keys($scope.downloadings).length;
					if(downLength >= 1) {
						$scope.hasDownload = false;
						$scope.downloadings[localName].showItem = true;
						if(downLength >= updateLength) {
							$scope.hasUpdate = true;
						};
					};
					//触发下载列队事件
					//判断是否第一次下载
					var localDownBook = storedb("allDownload").find();
					var downBookName = localDownBook.downBookName;
					if(downBookName === undefined) {
						$scope.downloadings[localName].loadIcon = true;
						$scope.downloadings[localName].status = "下载中";
						//添加到下载列队
						kexAppJson.pushLocal(updateId);
						kexApp.kexJson.updateLocal("version", 3, updateId)
						kexApp.kexJson.updateLocal("status", "下载中", updateId)
						var newDate = new Date();
						var nowTime = newDate.getTime();
						kexApp.kexJson.updateLocal("nowTime", nowTime, updateId)
						var BookName = $scope.downloadings[localName].id;
						var size=$scope.downloadings[localName].size;
						var downloadurl=$scope.downloadings[localName].fileMap;
						var realname=$scope.downloadings[localName].file;
						window.location.href = "uniwebview://getordown?name=" + BookName 
						+"&realname=" + realname 
						+"&size=" +size 
						+"&downloadurl="+downloadurl; //更改后
					}else if(downBookName != undefined) {
						kexAppJson.pushLocal(updateId);
						for(var i = 0; i < downBookName.length; i++) {
							var localName = downBookName[i];
							//如果当,正在下载的书籍状态是暂停的，那么当前书籍应该下载
							if(localDownBook[localName].version === 4) {

								$scope.downloadings[localName].loadIcon = true;
								$scope.downloadings[localName].status = "下载中";
								$scope.downloadings[localName].version = 3;
								var BookName = $scope.downloadings[localName].id;
								var realname = $scope.downloadings[localName].file;
								var Booktype = "";
								var size=$scope.downloadings[localName].size;
								var downloadurl=$scope.downloadings[localName].fileMap;
								//添加到下载列队
								window.location.href = "uniwebview://getordown?name=" + BookName 
								+ "&realname=" + realname
								+ "&size=" + size
								+"&downloadurl="+downloadurl; //下载对应书籍
								kexAppJson.pushLocal(updateId);
								kexApp.kexJson.updateLocal("version", 3, updateId)
								kexApp.kexJson.updateLocal("status", "下载中", updateId)
								var newDate = new Date();
								var nowTime = newDate.getTime();
								kexApp.kexJson.updateLocal("nowTime", nowTime, updateId)
							};
							//如果有一个正在下载，那么当前的显示等待
							if(localDownBook[downBookName[i]].version === 3) {
								$scope.downloadings[localName].loadIcon = false;
								$scope.downloadings[localName].wait = true;
								$scope.downloadings[localName].status = "等待中";
								$scope.downloadings[localName].version = 5;
								kexApp.kexJson.updateLocal("version", 5, updateId);
								kexApp.kexJson.updateLocal("status", "等待中", updateId);
							}
						}
					}
				}
//真实删除
			
			$scope.hideItem = function($event) {
				this.downloading.showItem = false;
				SweetAlert.swal(this.downloading.title + "已取消下载！");
				window.location.href = "uniwebview://delete?name=" + this.downloading.id;
				kexAppJson.removeLocal(this.downloading.id);
				kexAppJson.removeDownName(this.downloading.id);
				var local = storedb("allDownload").find();
				var downName = local.downBookName;
				if(downName.length === 0) {
					$scope.hasDownload = true;
					delete local.downBookName;
					localStorage.setItem("allDownload", JSON.stringify(local))
				}
			}

			//下载状态
			var downBooks = $scope.downloadings;
			$scope.indicatorOption = {
				radius: 20,
				percentage: true,
				barColor: "#90a200",
				displayNumber: false,
				initValue: 0,
				barWidth: 4
			}
			$scope.changeValue = function(bookId, val) {
				radialIndicatorInstance[bookId].animate(val);
			}

			for(var db in downBooks) {
				var downBookEl = document.getElementsByClassName("downloading");
				var localDown = storedb("allDownload").find();
				var thisDownBook = localDown[db];
				
				var unityBookName = downBooks[db].id;
				var size=downBooks[db].size;
				var downloadurl=downBooks[db].fileMap;
				var realname=downBooks[db].file;
				
				if(thisDownBook.version === 3) {
					downBooks[db].status = "下载中";
					downBooks[db].version = 3;
					downBooks[db].isDown = true;
					downBooks[db].loadIcon = true;
					window.location.href = "uniwebview://getordown?name=" + unityBookName 
					+ "&realname=" + realname 
					+ "&size=" +size 
					+ "&downloadurl="+downloadurl;
				};
				
				if(thisDownBook.version === 4) {
					downBooks[db].status = "暂停中";
					downBooks[db].version = 4;
					downBooks[db].isDown = false;
					downBooks[db].loadIcon = true;
					window.location.href = "uniwebview://suspended?name=" + unityBookName 
					+ "&realname=" + realname; //暂停下载对应书籍
				};
				
				if(thisDownBook.version === 5) {
					downBooks[db].status = "等待中";
					downBooks[db].version = 5;
					downBooks[db].wait = true;
					downBooks[db].loadIcon = false;
					window.location.href = "uniwebview://suspended?name=" + unityBookName 
					+ "&realname=" + realname; //下载对应书籍
				}
			}
			//点击改变
			$scope.downOrStop = function($event) {
				console.log(this.downloading)
				var unityBookName = this.downloading.id;
				var downloadurl = this.downloading.fileMap;
				var size=this.downloading.size;
				var realname=this.downloading.file;
				if(this.downloading.status === "下载中") {
					this.downloading.status = "暂停中";
					this.downloading.version = 4;
					kexAppJson.updateLocal("version", 4, this.downloading.id);
					kexAppJson.updateLocal("status", "暂停中", this.downloading.id);
					this.downloading.isDown = false;
					window.location.href = "uniwebview://suspended?name=" + unityBookName 
					+ "&realname=" + realname; //下载对应书籍

				} else if(this.downloading.status === "暂停中") {
					//更换图标
					this.downloading.isDown = true;
					//当前的显示下载，正在下载的书本暂停
//					setTimeout(function() {
//							downloading(100, unityBookName);
//						}, 1000);
							window.location.href = "uniwebview://getordown?name=" + unityBookName 
							+ "&realname=" + realname 
							+ "&size=" +size 
							+ "&downloadurl="+downloadurl;
							this.downloading.status = "下载中";
							this.downloading.wait = false;
							this.downloading.loadIcon = true;
							this.downloading.version = 3;
							kexAppJson.updateLocal("version", 3, this.downloading.id);
							kexAppJson.updateLocal("status", "下载中", this.downloading.id);
							var thisDid = this.downloading.id;
				}
			}
			
			$scope.openBook = function() {
				var unityBookName = this.complete.id;
				var localName = unityBookName + localUser.phone;
				var realname = this.complete.file;
				var mediaType = this.complete.mediaType;
				$rootScope.details = $scope.completes[localName];
				if(mediaType == 'image' || mediaType == 'video' || mediaType == 'audio') {
					$state.go('mediaShow')
				}else if(mediaType == 'html'){
					window.location.href = "uniwebview://changeLandscape?name=" + realname;
						setTimeout(function(){
						window.location.href =realname + ".html";
							},300);
					}
				else {
					window.location.href = "uniwebview://changeLandscape?name=" + realname;
					$("#cover").addClass("loadImg");
					$("#dt").addClass("blackBg");
					setTimeout(function(){
						window.location.href = "./"  + realname + "/book/index.html?user=hhh";
					},300);
				}
			}
			if($scope.updateDls === undefined || $scope.updateDls.length === 0) {
				$scope.hasUpdate = true;
			};
			if($scope.completes === null || $scope.completes === undefined || Object.keys($scope.completes).length === 0) {
				$scope.hasComplete = true;
			};
			if($scope.downloadings === null || Object.keys($scope.downloadings).length === 0) {
				$scope.hasDownload = true;
			};
		}
	])