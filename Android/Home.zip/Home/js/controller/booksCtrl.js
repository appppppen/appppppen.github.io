angular
	.module("kexApp")
	.controller("booksCtrl", ["$scope",
		"$state",
		"$stateParams",
		"radialIndicatorInstance",
		"httpService",
		"$rootScope",
		function($scope, $state, $stateParams, radialIndicatorInstance, httpService,$rootScope) {
			$scope.leftIcon = "./img/icon/left.png";
			$scope.bookddW = (window.innerWidth - 125) + "px";
			window.onresize = function() {
				var bookddW = window.innerWidth - 125;
				$(".update dl dd").css({
					width: bookddW
				})
			};
			window.onorientationchange = function() {
				var bookddW = window.innerWidth - 125;
				$(".update dl dd").css({
					width: bookddW
				})
			};
			$scope.downAnimateIcon = "./img/icon/downOrStopIcon.png";
			var bookId = $stateParams.booksId;
			//书籍名称
			$scope.books = [];
			var getBookAfter = function(){
				var books = kexAppJson.allBooksDetails[bookId].list;
				$scope.booksName = kexAppJson.allBooksDetails[bookId].courseware.title;
				$scope.booksInfo = kexAppJson.allBooksDetails[bookId].courseware.description;
				console.log(books)
				for(var i=0;i<books.length;i++){
					books[i]['type'] = books[i].tag.split(',');
				}
				$scope.books = books;
				$scope.$apply();
			};
			kexAppJson.getBookById(bookId,getBookAfter);
			$scope.toThisBook = function(book) {
				var bookData = book.id;
				$state.go('details', {
					detailId: bookData
				})
			};
		}
	])