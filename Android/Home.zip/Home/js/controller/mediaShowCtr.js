angular
	.module("kexApp")
	.controller("mediaShowCtr", ["$scope", "$http", "$state", "httpService", '$rootScope',
		function($scope, $http, $state, httpService, $rootScope) {
			var details = $rootScope.details;

			$scope.showVedio = $scope.showImg = false;
			$scope.rechargeImgSize = function(ele) {
				var width = $(ele).find('img').width();
				var height = $(ele).find('img').height();
				var rate = width / height;
				if(rate >= $scope.rate) { //宽度超出
					$(ele).remove('heightM').addClass('widthM');
				} else { //高度超出
					$(ele).remove('widthM').addClass('heightM');

				}
			};

			var msgarray = details.fileMap.split("$split$");
			var str = msgarray[0];
			str = str.replace(/'/g, '"');
			var jsonobj = JSON.parse(str);
			var url = new Array();
			for(var i in jsonobj) {
				url.push(jsonobj[i]);
			}
			var localSource = {};
			var type = details.mediaType;
			if(type == 'image') {
				$rootScope.isMedia = 'image';
				$scope.showVedio = false;
				$scope.showImg = true;
				var images = url;
				$scope.detailsImgs = images;
				$scope.imgsLen = images.length;
				$rootScope.nowImg = $scope.detailsImgs[0];
				$scope.rechargeImgSize('.nowImg');
				$scope.imageIndex = 0;
			} else if(type == 'video') {
				$rootScope.isMedia = 'video';
				$scope.showImg = false;
				$scope.showVedio = true;
				$scope.videoSrc = url[0];
			} else if(type == 'audio') {

				$rootScope.isMedia = 'audio';
				$scope.showImg = false;
				$scope.showVedio = true;
				$scope.videoSrc = url[0];
				$scope.poster = 'img/cc/2.jpg';
			}
			$scope.goBack = function() {
				window.location.href = "javascript:history.go(-1)"
			};

		}
	])

//图片滑动
kexApp.directive('showImg', function($rootScope) {
	return {
		restrict: 'C',
		link: function(scope, element) {
			scope.postitionX = 0;
			scope.isMoving = false;

			element.bind('touchstart', function(e) {
				scope.postitionX = e.touches[0].pageX;
			});
			element.bind('touchend', function(e) {
				var now = e.changedTouches[0].pageX;
				var changeImg = $(element).find('.changeImg');
				var nowImg = $(element).find('.nowImg');
				if(scope.imgsLen <= 1 || scope.isMoving) {
					return;
				}

				if(now > scope.postitionX) {
					console.log('向右滑动')
					scope.imageIndex--;
					if(scope.imageIndex < 0) {
						scope.imageIndex = 0;
						return;
					}
					scope.isMoving = true;
					changeImg.css('left', -window.innerWidth + 'px');
					changeImg.find('img').attr('src', scope.detailsImgs[scope.imageIndex]);
					nowImg.find('img').attr('src', '');
					$rootScope.nowImg = scope.detailsImgs[scope.imageIndex];
					$rootScope.chargeImg(changeImg.find('img'), scope.detailsImgs[scope.imageIndex]);
					changeImg.animate({
						'left': 0
					}, 'slow', function() {
						$rootScope.chargeImg(nowImg.find('img'), scope.detailsImgs[scope.imageIndex]);
						nowImg.find('img').attr('src', scope.detailsImgs[scope.imageIndex]);
						scope.isMoving = false;
					});

				} else {
					console.log('向左滑动');
					changeImg.css('left', window.innerWidth + 'px');
					if(scope.imageIndex >= (scope.imgsLen - 1)) {
						return;
					}
					scope.isMoving = true;
					scope.imageIndex++;
					changeImg.find('img').attr('src', scope.detailsImgs[scope.imageIndex]);
					nowImg.find('img').attr('src', '');
					$rootScope.nowImg = scope.detailsImgs[scope.imageIndex];
					$rootScope.chargeImg(changeImg.find('img'), scope.detailsImgs[scope.imageIndex]);
					changeImg.animate({
						'left': 0
					}, 'slow', function() {
						$rootScope.chargeImg(nowImg.find('img'), scope.detailsImgs[scope.imageIndex]);
						nowImg.find('img').attr('src', scope.detailsImgs[scope.imageIndex]);
						scope.isMoving = false;
					});

				}

			})
		}
	}

})

//链接改变
kexApp.directive('img', function($rootScope) {
	return {
		restrict: 'C',
		link: function(scope, element, attr) {

			$rootScope.chargeImg = function(element, src) {
				console.log('123')
				var windowRate = window.innerWidth / window.innerHeight;
				var img = new Image();
				img.src = src;
				img.onload = function() {
					var width = img.width;
					var height = img.height;
					var imgRate = width / height;
					var parent = $(element).parent();

					if(imgRate >= windowRate) { // 宽度大于高度的比例

						var half = (window.innerHeight - window.innerWidth / imgRate) / 2;
						$(element).css('margin-top', half + 'px');
						parent.removeClass('widthM').addClass('heightM');

					} else { // 高度大于宽度的比例
						$(element).css('margin-top', 0);
						parent.removeClass('heightM').addClass('widthM');
					}

				}
			};

			attr.$observe('src', function(val) {
				$rootScope.chargeImg(element, val);
			})

		}
	}

})

//视频处理
kexApp.directive('video', function($rootScope) {
	return {
		restrict: 'C',
		link: function(scope, element, attr) {

			$rootScope.orientation = function(ele) {

				console.log(window.innerHeight)
				console.log((window.innerHeight-70)/2)
				if($rootScope.isMedia == 'audio') {
					$(ele).css({
						'margin-top': (window.innerHeight-70)/2,
						'height': '70px',
						'width': '100%'
					});
					return;
				}

				var winRate = window.innerWidth / window.innerHeight;
				var rate1 = 1920 / 1080;
				var rate2 = 1920 / 1440;

				$(ele).css({
					'width': '100%',
					'height': 'auto'
				});
				var height = $(ele).height();
				var width = $(ele).width();
				if(winRate < 1 || winRate == rate1 || winRate == rate2) { //竖屏
					console.log('竖屏或分辨率相同')
					var half = (window.innerHeight - height) / 2;
					$(ele).css({
						'margin-top': half + 'px',
						'width': '100%',
						'height': 'auto'
					});
				} else { //横屏
					console.log('横屏');
					$(ele).css({
						'margin-top': 0,
						'height': '100%',
						'width': 'auto'
					});
				}

			};
			$rootScope.orientation(element);

			$(window).on("orientationchange", function() {
				console.log('orientationchange');
				//if($rootScope.isMedia) {
					if($rootScope.isMedia == 'image') {
						$rootScope.chargeImg('.nowImg .img', $rootScope.nowImg);
						$rootScope.chargeImg('.changeImg .img', $rootScope.nowImg);
					} else {
						$rootScope.orientation('.video');
					}
				//}

			});

			$(window).on("resize ", function() {
				console.log('resize')
				//if($rootScope.isMedia) {
				if($rootScope.isMedia == 'image') {
					$rootScope.chargeImg('.nowImg .img', $rootScope.nowImg);
					$rootScope.chargeImg('.changeImg .img', $rootScope.nowImg);
				} else {
					$rootScope.orientation('.video');
				}
				//}

			});

		}
	}

})