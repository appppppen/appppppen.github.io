angular
	.module("kexApp")
	.controller("stackCtrl", ["$scope",
		"$http",
		"$state",
		"httpService",
		'$rootScope',
		function($scope, $http, $state, httpService,$rootScope) {
			$scope.downloadIcon = "./img/icon/download.png";
			$scope.stddw = (window.innerWidth - 110) + "px";
			var bannerHeight =  window.innerWidth * 37 / 75 +"px";
			$(".stack_banner").css('height',bannerHeight);
			$(".swiper-container").css('height',bannerHeight);
			var token=''
			var user = JSON.parse(localStorage.getItem("user"));
			if(user){
				token=user.token;
			}
			$scope.toUpdate = function() {
				$state.go("update")
			};
			if(token){
				$http({
					url: $scope.serviceUrl+'courseware/list/top/',
					method: 'GET',
					params:{token:token}
				}).success(function(data){
					$scope.lunbo = false;
					console.log(data);
					$('.swiper-slide').remove();
					var arr = data.result;
					var image_arr=[];
					for(i in arr){
						var obj={};
						obj.src=arr[i].detail.bannerImage;
						image_arr.push(obj);
					}					
					for(var i=0;i<image_arr.length;i++){
					    $('.swiper-wrapper').append('<div class="swiper-slide"><a style="background-image: url('+image_arr[i].src+');"></a></div>');
					}
					var mySwiper = new Swiper('.swiper-container',{
						pagination : '.swiper-pagination',
						paginationClickable :true,
						loop:true,
						autoplay:4000,
						slidesPerView: 1,
    					observer:true,
    					observeParents:true,
    					autoplayDisableOnInteraction : false,
    					onSlideChangeEnd: function(swiper){ 
    						var bannerheight =  window.innerWidth * 37 / 75 +"px";
							$(".stack_banner a").css('height',bannerheight);							
							window.onresize = function() {
								var stddw = window.innerWidth - 110;
								var bannerheight = window.innerWidth * 37 / 75 +"px";
								$(".stack-list dl dd").css({
									width: stddw
								});
								$(".stack_banner").css('height',bannerheight);
								$(".swiper-container").css('height',bannerheight);
								$(".stack_banner a").css('height',bannerheight);
							};
							window.onorientationchange = function() {
								var stddw = window.innerWidth - 110;
								var bannerheight = window.innerWidth * 37 / 75 +"px";
								$(".stack-list dl dd").css({
									width: stddw
								});
								$(".stack_banner").css('height',bannerheight);
								$(".swiper-container").css('height',bannerheight);
								$(".stack_banner a").css('height',bannerheight);
							};
					        swiper.update(); //swiper更新					        
					    }  
					});
				}).error(function(data){
					$scope.lunbo = true;
					console.log(data);
				})
			}else{
			$scope.bimgs = [{
                    src: "./img/images/lunbo1.png"
                }, {
                    src: "./img/images/lunbo2.png"
                }, {
                    src: "./img/images/lunbo3.png"
                }];

				var mySwiper = new Swiper('.swiper-container', {
					pagination : '.swiper-pagination',
					paginationClickable :true,
					loop:true,
					autoplay:4000,
					slidesPerView: 1,
    				observer:true,
    				observeParents:true,
    				autoplayDisableOnInteraction : false,
    				onSlideChangeEnd: function(swiper){
    					swiper.update(); //swiper更新	
    				}
				})
			}
			
			
			
			$scope.toImgDetail = function() {
					$state.go()
			};
			var getBookList = function(){
				$scope.stackBjtj = [];
				$scope.stackCnxh = [];
				$scope.stackCxcp = [];
				var allBook = kexAppJson.allRecommendList;
				var nowObj,b,arr,str,isSeries,book,i;
				var arr=[];
				for(b in allBook.bjtj){
					nowObj = allBook.bjtj[b];
					book = allBook.bjtj[b];
					nowObj['type'] =[];
					if(nowObj['tag']){
						arr = nowObj['tag'].split(',');
					}
					for(i=0;i<arr.length;i++){
						if(arr[i]){
							nowObj['type'].push(arr[i]);
						}
					}
					$scope.stackBjtj.unshift(nowObj);
				}
				for(b in allBook.cnxh){
					nowObj = allBook.cnxh[b];
					book = allBook.cnxh[b];
					nowObj['type'] =[];
					if(nowObj['tag']){
						arr = nowObj['tag'].split(',');
					}
					for(i=0;i<arr.length;i++){
						if(arr[i]){
							nowObj['type'].push(arr[i]);
						}
					}
					$scope.stackCnxh.unshift(nowObj);
				}
				for(b in allBook.cpcx){
					nowObj = allBook.cpcx[b];
					book = allBook.cpcx[b];
					nowObj['type'] =[];
					if(nowObj['tag']){
						arr = nowObj['tag'].split(',');
					}
					for(i=0;i<arr.length;i++){
						if(arr[i]){
							nowObj['type'].push(arr[i]);
						}
					}
					$scope.stackCxcp.unshift(nowObj);
				}
				$scope.$apply();
			};
			kexApp.kexJson.getAllBooksList(getBookList);

			//判断当前书本
			$scope.toThisDet = function() {
				//用户数据采-获取素材的id					
				$rootScope.watched = this.stackDl.id;
				$rootScope.startTime = String(new Date().getTime());

				//传递当前书本的id
				$state.go('details', {
					detailId: this.stackDl.id
				})
			};
			$scope.img_click = function() {
				var name=$('.stack_banner .swiper-slide-active').css('backgroundImage').slice(-12);
				if(name=='lunbo3.png")'){
					window.location.href = "uniwebview://OpenUrl?url=ssss";
					setTimeout(
						function(){
							window.location.href="https://item.taobao.com/item.htm?spm=2013.1.0.0.JVAGwk&id=527683948171&scm=1007.11962.53817.100200300000000&pvid=8c4de05f-c327-4fb9-bd9a-896e17b1befc&idnum=0/";
						},50
					)
							$state.go(this.stackHot.isbooks, {
								detailId: data.id,
								booksId: data.id
							})
					}

				};
			//分类部分
			$scope.classify={
				'type':1,
				'changeType':function(type){
					kexApp.kexJson.getAllBooksList(getBookList);
					if($scope.classify.type == type){return;}
					$scope.classify.type = type;
					if(type == 4){
						$state.go('classify')
					}
				}
			};
		}
	])
