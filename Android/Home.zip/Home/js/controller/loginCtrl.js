angular
	.module("kexApp")
	.controller("loginCtrl", ["$scope","$http","$rootScope",
		function($scope,$http,$rootScope) {
			window.location.href = "uniwebview://GetCid?name=ww";
			$scope.login_qq=function(){
				 window.location.href = "uniwebview://qqlogin?Get=s";
			}
			$scope.login=function(){
				var clientId=localStorage.getItem('clientid');
				if($scope.myForm.$valid){
					$http({
					   url:$scope.serviceUrl+'auth/login',
					   method:'POST',  
					   params:{phone:$scope.phone,password:$scope.password,clientId:clientId}
			  		}).success(function (data) {
			  			var msg=data.msg;
						localStorage.setItem("user", JSON.stringify(data.userInfo))
						var user=data.userInfo;
						console.log(user.token)
						window.location.href = "uniwebview://gettoken?token="+user.token;
						$rootScope.logined = true;
						if(user.headImg){
							$rootScope.userPic = user.headImg;
						}
						//用户数据采-用户登录
						var login = {};
						login.startTime = String(new Date().getTime());
						login.contentType = 'login';
						login.contentId = $scope.phone;
						login.device = localStorage.getItem("deviceId");
						kexAppJson.action.push(login);
						window.location.href="index.html#/userCenter";
			  		}).error(function(data){
			  			var msg=data.msg;
			  			swal(msg);
			  			console.log(msg);
			  		})
				}else{
					if($scope.myForm.phone.$error.required){
						swal('请输入手机号')
					}else if($scope.myForm.phone.$error.pattern){
						swal('手机号不正确')
					}else if($scope.myForm.password.$error.required){
						swal('请输入密码')
					}
				}
			}
		}
	])