angular
	.module("kexApp")
	.controller("rechargeCtrl", ["$scope","$http",
		function($scope,$http) {
			var user = JSON.parse(localStorage.getItem("user"));
			var token=user.token;
			$scope.coin='0';
			$http({
			   url:$scope.serviceUrl+'user/account',
			   method:'GET',  
			   params:{
				   	token:token
			    }
	  		}).success(function (data) {
	  			$scope.coin=data.coin
	  			console.log(data)
	  		}).error(function(data){
	  			console.log(data)
	  		})
			$scope.recharge=function(){
				if(isNaN($scope.recharge_num)||$scope.recharge_num<=0||$scope.recharge_num==undefined){ 
			        swal('请输入充值数量')
			        return;
			    }else if($scope.recharge_num-parseInt($scope.recharge_num)!=0){
			    	swal('请输入整数充值')
			        return;
			    }
				$http({
				   url:$scope.serviceUrl+'pay/recharge',
				   method:'POST',  
				   params:{
					   	token:token,
					   	num:$scope.recharge_num
				    }
		  		}).success(function (data) {
		  			console.log(data.signedString)
		  			window.location.href = "uniwebview://pay?" + data.signedString;
		  		}).error(function(data){
		  			console.log(data)
		  		})
			}
		}
	])