angular
	.module("kexApp")
	.controller("detailCtrl", ["$scope",
		"$stateParams",
		"$http",
		"$localStorage",
		"radialIndicatorInstance",
		"$state",
		"httpService",
		'SweetAlert',
		'$rootScope',
		'$location',
		'$anchorScroll',
		function($scope, $stateParams, $http, $localStorage, radialIndicatorInstance, $state, httpService, SweetAlert, $rootScope, $location, $anchorScroll) {
			$rootScope.isMedia = false;
			$scope.nowPage = 1;
			$scope.totolPage = 0;
			var downloadurl = '';
			var realname = '';
			var size = '';
			var user = JSON.parse(localStorage.getItem("user"));
			var token = user.token;
			book_download = {};
			$scope.leftIcon = "./img/icon/left.png";
			//下载状态
			$scope.downAnimateIcon = "./img/icon/downOrStopIcon.png";
			//获取dd的宽度
			$scope.detddW = (window.innerWidth - 140) + "px";
			$scope.rate = window.innerWidth / window.innerHeight; //页面分辨率
			window.onresize = function() {
				var ddW = window.innerWidth - 120;
				$(".detail_head dd").css({
					width: ddW
				})
			};
			window.onorientationchange = function() {
				var ddW = window.innerWidth - 120;
				$(".detail_head dd").css({
					width: ddW
				})
			};
			//当前页面id
			var detailId = $stateParams.detailId;
			$scope.thisId = detailId;
			//callback 获取书籍后的加载
			var afterGetDetails = function() {
				$rootScope.$apply(function() {
					arr = kexAppJson.allBooksDetails[detailId].previews;
					$scope.viewShow = false;
					if(arr) {
						$scope.views = arr.split(',');
						$scope.viewShow = false;
						var str = '';
						var mySwiper = new Swiper('.swiper-container', {
							slidesPerView: 1,
							spaceBetween: 0,
							observer: true,
							observeParents: true,
						});
					} else {
						$scope.viewShow = true;
					}
					var sb = kexAppJson.allBooksDetails[detailId].courseware;
					if(sb.file == null) {
						var msgarray = sb.fileMap.split("$split$");
						var str = msgarray[0];
						if(str != "{}" && str.toLocaleLowerCase().indexOf(".zip") > 0) {
							str = str.replace(/'/g, '"');
							var jsonobj = JSON.parse(str);
							var url;
							for(var i in jsonobj) {
								if(jsonobj[i].toLocaleLowerCase().indexOf(".zip") > 0) {
									url = jsonobj[i];
								}
							}
							sb.file = url.split(".")[0];
						}else if(str != "{}"&& str.toLocaleLowerCase().indexOf(".zip") < 0 && str.toLocaleLowerCase().indexOf(".html") > 0) {
							str = str.replace(/'/g, '"');
							var jsonobj = JSON.parse(str);
							var url;
							for(var i in jsonobj) {
								if(jsonobj[i].toLocaleLowerCase().indexOf(".html") > 0) {
									url = jsonobj[i];
								}
							}
							sb.file = url.split(".")[0];
						} else {
							sb.file = sb.id;
						}
					} else {
						var sb2 = sb.file;
					}
					$rootScope.details = sb;
					var discount = kexAppJson.allBooksDetails[detailId].discount;
					if(discount == null) {
						$scope.xianshi = false;
					} else {
						$scope.xianshi = true;
						$rootScope.discount = discount;
						$scope.yuanjia = '原价'
					}
					//获取素材的tag，记录用户刚进详情页面的时间
					$scope.buy_details = kexAppJson.allBooksDetails[detailId].bought;
					$rootScope.details.info = $rootScope.details.description
					var str = $rootScope.details.tag;
					localStorage.setItem("tag", str);
					localStorage.setItem("startTime", new Date().getTime());
					$rootScope.componentBaseId = $rootScope.details.coursewareBaseId;
					if(str) {
						$rootScope.details.tag = str.split(',');
					}
					//获取用户评价列表
					httpService.getComment($rootScope.componentBaseId, $scope.nowPage, token).then(function(data) {
						$scope.results = data.data.result;
						$scope.totolPage = data.data.pageCount;
					}, function() {
						console.log('加载失败');
					});
					$scope.toPrePage = function() {
						$scope.nowPage--;
						if($scope.nowPage <= 1) {
							$scope.nowPage = 1;
							return;
						}
						httpService.getComment($rootScope.componentBaseId, $scope.nowPage, token).then(function(data) {
							$scope.results = data.data.result;
							$location.hash('plstart');
							$anchorScroll();
						}, function() {
							console.log('加载失败');
						});
					};
					$scope.toNextPage = function() {
						$scope.nowPage++;
						if($scope.nowPage >= $scope.totolPage) {
							$scope.nowPage = $scope.totolPage;
							return;
						}
						httpService.getComment($rootScope.componentBaseId, $scope.nowPage, token).then(function(data) {
							$scope.results = data.data.result;
							$location.hash('plstart');
							$anchorScroll();
						}, function() {
							console.log('加载失败');
						});
					};
					//记录用户退出详情页的时间，用来做用户数据采集
					$scope.getEndTime = function() {
						//用户数据采-看了哪些书
						var book_detail = {};
						var bookDetail = [];
						book_detail.startTime = $rootScope.startTime;
						book_detail.contentType = 'book_detail';
						book_detail.contentId = token;
						book_detail.device = localStorage.getItem("deviceId");
						book_detail.endTime = String(new Date().getTime());
						bookDetail.push(book_detail);
						var bookDetail = JSON.stringify(bookDetail[0]);
						$http({
							url: $scope.serviceUrl + 'courseware/visit/' + $rootScope.componentBaseId,
							method: 'POST',
							params: {
								token: token,
							}
						}).success(function(data) {
							var msg = data.msg;
							console.log(msg);
						}).error(function(data) {
							var msg = data.msg;
							console.log(msg);
						})
						window.location.href = "javascript:history.go(-1)"
					};
				});
				downloadurl = $rootScope.details.fileMap;
				realname = $rootScope.details.file;
				size = $rootScope.details.size;
				bookId = $rootScope.componentBaseId;
				mediaType=$rootScope.details.mediaType;
				//书籍状态
				var localUser =  storedb("user").find();
				var localName = detailId+localUser.phone;
				var downBook = storedb("allDownload").find()[localName];
				if(downBook === undefined ) {
					$scope.$apply(function() {
						$scope.details.status = '获取';
						$scope.details.version = 0;
					});
				}else{
					//页面加载时
					if(downBook.version == 2){
						$scope.details.status = '打开';
					}else if(downBook.version === 3) {
						$(".detail_head dd img").css({
							left: "17px"
						});
						$(".downIcon").removeClass("hidden");
						$("#detailStatus").addClass("hidden");
					}else if(downBook.version === 4) {
						$(".detail_head dd img").css({
							left: "-16px"
						});
						$(".downIcon").removeClass("hidden");
						$("#detailStatus").addClass("hidden");
						$scope.details.status = kexApp.kexJson.getBtnStatus(downBook.version);
					}
				};
			};
			//课件详情页的内容简介
			kexApp.kexJson.getBookById(detailId, afterGetDetails);
			//打星星評价
			$scope.srcx1 = $scope.srcx2 = $scope.srcx3 = $scope.srcx4 = $scope.srcx5 = './img/icon/wujiaoxingkongxing.png';
			var index = 0;
			$scope.getEvaluate = function(data) {
				index = data;
				switch(data) {
					case 1:
						$scope.srcx1 = './img/icon/wujiaoxingshixing.png';
						$scope.srcx2 = $scope.srcx3 = $scope.srcx4 = $scope.srcx5 = './img/icon/wujiaoxingkongxing.png';
						break;
					case 2:
						$scope.srcx1 = $scope.srcx2 = './img/icon/wujiaoxingshixing.png';
						$scope.srcx3 = $scope.srcx4 = $scope.srcx5 = './img/icon/wujiaoxingkongxing.png';
						break;
					case 3:
						$scope.srcx1 = $scope.srcx2 = $scope.srcx3 = './img/icon/wujiaoxingshixing.png';
						$scope.srcx4 = $scope.srcx5 = './img/icon/wujiaoxingkongxing.png';
						break;
					case 4:
						$scope.srcx1 = $scope.srcx2 = $scope.srcx3 = $scope.srcx4 = './img/icon/wujiaoxingshixing.png';
						$scope.srcx5 = './img/icon/wujiaoxingkongxing.png';
						break;
					case 5:
						$scope.srcx1 = $scope.srcx2 = $scope.srcx3 = $scope.srcx4 = $scope.srcx5 = './img/icon/wujiaoxingshixing.png';
						break;
				}
			};
			//提交评价
			$scope.submitEvaluate = function() {
				if(!$rootScope.componentBaseId || !token) {
					return;
				}
				if(!$scope.buy_details){
					swal('请先购买图书');
				}else if(!$scope.textarea){
					swal('请先输入评价');
				}else{
					$http({
					url: $scope.serviceUrl + 'courseware/comment/add',
					method: 'POST',
					params: {
						token: token,
						content: $scope.textarea,
						score: index,
						productId: $rootScope.componentBaseId
					}
					}).success(function(data) {
						var msg = data.msg;
						console.log(msg); //评论成功,重新加载评论,星星归为，text清空
						$scope.nowPage = 1;
						httpService.getComment($rootScope.componentBaseId, $scope.nowPage, token).then(function(data) {
							$scope.results = data.data.result;
							$scope.totolPage = data.data.pageCount;
						}, function() {
							console.log('加载失败');
						});
						$scope.textarea = '';
						$scope.srcx1 = $scope.srcx2 = $scope.srcx3 = $scope.srcx4 = $scope.srcx5 = './img/icon/wujiaoxingkongxing.png';
					}).error(function(data) {
						var msg = data.msg;
						console.log(msg);
					})
				}
			};
			//前往周边页面
			$scope.toThisCircum = function() {
				$state.go("circum");
			};
			// //按钮事件
			$scope.indicatorOption = {
				radius: 20,
				percentage: true,
				barColor: "#90a200",
				displayNumber: false,
				initValue: 0,
				barWidth: 4
			};
			$scope.changeValue = function(bookId, val) {
				radialIndicatorInstance[bookId].animate(val);
			};
			//点击按钮模拟下载进度
			$scope.bookEvent = function() {
				var bookImg = this.details.img;
				var bookStatus = this.details.status;
				var bookName = this.details.name;
				var bookVersion = this.details.version;
				var bookId = $rootScope.details.id;
				//在详情页更改状态，添加视觉效果
				if(bookStatus === "获取") {
					//用户数据采-用户下载
					book_download.startTime = String(new Date().getTime());
					book_download.contentType = 'book_download';
					book_download.contentId = bookId;
					book_download.device = localStorage.getItem("deviceId");
					kexAppJson.action.push(book_download);
					var localDownBook = storedb("allDownload").find();
					var downBookName = localDownBook.downBookName;
					var detail_container = document.getElementsByClassName("detail_container");
						$(".downIcon").removeClass("hidden");
						$("#detailStatus").addClass("hidden");
						$scope.details.status = "下载中";
						$scope.details.version = 3;
						//存成本地缓存
						kexApp.kexJson.setLocal(this.details);
						//添加到下载列队
						kexAppJson.pushLocal(bookId);
						kexApp.kexJson.updateLocal("version", 3, bookId);
						kexApp.kexJson.updateLocal("status", "下载中", bookId);
						var newDate = new Date();
						var nowTime = newDate.getTime();
						kexApp.kexJson.updateLocal("nowTime", nowTime, bookId);
//						setTimeout(function() {
//							downloading(100, bookId);
//						}, 1000);
						window.location.href = "uniwebview://getordown?name=" + bookId +
							"&realname=" + realname +
							"&size=" + size +
							"&downloadurl=" + downloadurl;
				}

				var localBooks = storedb("allDownload").find();
				var localUser = storedb("user").find();
				var localName = detailId+localUser.phone;
				var localSource = localBooks[localName];
				if(localSource.status === "打开") {
					$scope.details.status = '打开';
					book_download.endTime = String(new Date().getTime());
					kexAppJson.action.push(book_download);
					//做判断 ，如果是图片，或者是视频做处理
					if(mediaType == 'image' || mediaType == 'video' || mediaType == 'audio') {
						$state.go('mediaShow')
					}else if(mediaType == 'html'){
						window.location.href = "uniwebview://changeLandscape?name=" + realname;
							setTimeout(function(){
						window.location.href =realname + ".html";
							},300);
					}
					else {
						$("#cover").addClass("loadImg");
						$("#dt").addClass("blackBg");
						window.location.href = "uniwebview://changeLandscape?name=" + realname;
						setTimeout(function() {
							window.location.href = "./" + realname + "/book/index.html?user=hhh";
						}, 300);
					}
				}
				//绑定服务，让其他页面和外部调用,添加数据到更新页面
				kexApp.kexJson.statusEvent(
					bookId,
					bookStatus,
					bookImg,
					bookName,
					bookVersion
				)
			};

			//点击暂停和开始
			$scope.downOrStop = function() {
				var localDownBook = storedb("allDownload").find();
				var downBookName = localDownBook.downBookName;
				if(this.details.status === "下载中") {
					$(".detail_head dd img").css({
						left: "-16px"
					})
					this.details.status = "暂停中";
					this.details.version = 4;
					kexApp.kexJson.updateLocal("version", 4, detailId)
					kexApp.kexJson.updateLocal("status", "暂停中", detailId)
					var suspendedname = this.details.id;
					var suspendedrealname = this.details.file;
					window.location.href = "uniwebview://suspended?name=" + suspendedname + "&realname=" + suspendedrealname;
				} else if(this.details.status === "暂停中") {
					$(".detail_head dd img").css({
						left: "17px"
					})
					this.details.status = "下载中";
					kexAppJson.updateLocal("version", 3, detailId);
					kexAppJson.updateLocal("status", "下载中", detailId);
					var unityBookname = this.details.id;
					var unityrealname = this.details.file;
					var unityBooksize = this.details.size;
					var unityBookdownloadurl = this.details.fileMap;
					window.location.href = "uniwebview://getordown?name=" + unityBookname +
						"&realname=" + unityrealname +
						"&size=" + unityBooksize +
						"&downloadurl=" + unityBookdownloadurl;
				}
			}
			$scope.toPay = function(details) {
					var discount = kexAppJson.allBooksDetails[detailId].discount;
					if(discount == null) {
						var price = details.price;
					} else {
						var price = discount;
					}
					swal({
							title: "确认购买？",
							text: '购买会扣除你' + price + '虚拟币!',
							type: "warning",
							showCancelButton: true,
							confirmButtonColor: "#DD6B55",
							confirmButtonText: "购买",
							cancelButtonText: "取消",
							closeOnConfirm: false
						},
						function() {
							var id = details.id;
							var type = 'courseware'
							if(!id || !token || !type) {
								return;
							}
							var res = httpService.payMoney(token, id, type);
							res.then(function(data) {
								console.log(data)
								swal("购买成功!", "已从你的账户扣除" + price + '虚拟币!', "success")
								$scope.buy_details = true;
							}, function(data) {
								console.log(data)
								swal("购买失败!", data.data.msg, "error");
							})
						});
				}
				//打开事件
		}
	])
