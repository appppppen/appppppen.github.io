angular
	.module("kexApp")
	.controller("changeCtrl", ["$scope","$http",
		function($scope,$http) {
			$scope.change=function(){
				var user = JSON.parse(localStorage.getItem("user"));
			    if(user){
			    	var token=user.token;
			    	if($scope.myForm.$valid&&$scope.newPassword.length>=6){
						$http({
						   url:$scope.serviceUrl+'auth/password/change',
						   method:'POST',  
						   params:{
							   	token:token,
							   	oldPassword:$scope.oldPassword,
							   	newPassword:$scope.newPassword
						    }
				  		}).success(function (data) {
				  			var msg=data.msg;
				  			console.log(msg)
				  			localStorage.removeItem("user");
				  			$('.userPic img').attr('src','./img/images/user1.png');
							window.location.href = "index.html#/login";
				  		}).error(function(data){
				  			var msg=data.msg;
				  			swal(msg);
				  			console.log(msg);
				  		})
				  	}else{
				  		if($scope.myForm.oldPassword.$error.required){
							swal('请输旧密码')
						}else if($scope.myForm.newPassword.$error.required){
							swal('请输新密码')
						}else if($scope.newPassword.length<6){
							swal('密码不能少于6位')
						}
				  	}
		  		}
			}
		}
	])