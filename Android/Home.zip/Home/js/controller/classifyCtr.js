angular
	.module('kexApp')
	.controller('classify', ['$scope', '$state', '$stateParams', 'httpService', 'localService',
		function($scope, $state, $stateParams, httpService, localService) {

			$scope.leftIcon = './img/icon/left.png';
			$scope.bookType = '';
			$scope.classifyLists = [];
			$scope.nowLists = [];
			$scope.showClassList = 1;

			$scope.stddw = (window.innerWidth - 130) + "px";
			window.onresize = function() {
				var stddw = window.innerWidth - 130;
				$(".stack-list dl dd").css({
					width: stddw
				})
			};
			window.onorientationchange = function() {
				var stddw = window.innerWidth - 130;
				$(".stack-list dl dd").css({
					width: stddw
				})
			};

			$scope.loadEve = function() {
				$scope.classifyLists = kexAppJson.classifyList;
			};

			//获取分类列表
			if(kexAppJson.classifyList) {

				$scope.loadEve();

			} else {
				var req = httpService.getClassifyList();
				var obj;
				req.then(function(data) {
					kexAppJson.classifyList = [];
					for(var i = 0; i < data.data.length; i++) {
						obj = {};
						obj.name = data.data[i].name;
						kexAppJson.classifyList.push(obj);
					}
					localService.setLocal('classifyList', kexAppJson.classifyList);
					$scope.loadEve();
				}, function() {
					var res = localService.getLocal('classifyList');
					res.then(function(data) {
						for(var i = 0; i < data.length; i++) {
							obj = {};
							obj.name = data[i].name;
							kexAppJson.classifyList.push(obj);
						}
						$scope.loadEve();
					})

				})
			}

			$scope.toThisClass = function(obj) {
				$state.go('classifyBooks', {
					type: obj.name
				})
			};
		}
	]);