angular
	.module("kexApp")
	.controller("myOrderCtrl", ["$scope","$http",
		function($scope,$http) {
			$(".order_content").eq(0).css("border-top","0");
			//更新order_body的宽度
			$scope.order_width = (window.innerWidth - 105) + "px";
			window.onresize = function() {
				var order_width = window.innerWidth - 105;
				$(".order_body").css({
					width: order_width
				})
			};
			window.onorientationchange = function() {
				var order_width = window.innerWidth - 105;
				$(".order_body").css({
					width: order_width
				})
			};
			var user = JSON.parse(localStorage.getItem("user"));
			console.log(user);
			if(user) {
			 	var token = user.token;
			 	$http({
			 		url: $scope.serviceUrl + 'auth/user/order/list',
			 		method: 'GET',
			 		params: {token: token}
			 	}).success(function(data) {
			 		var msg = data.msg;
			 		console.log(data);
			 		$scope.orderList=data.orderList.result
			 		console.log($scope.orderList)
			 	}).error(function(data) {
			 		var msg = data.msg;
			 		console.log(msg);
			 	})
			}
		}
	])