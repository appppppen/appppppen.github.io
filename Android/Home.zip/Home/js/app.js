var kexApp = angular.module("kexApp", ["ngTouch",
    "ngAnimate",
    "ui.router",
    "ksSwiper",
    "ngStorage",
    "radialIndicator",
    "oitozero.ngSweetAlert",
    'ngSanitize']).run(function($rootScope){
    //定义一个全局函数，跳转到指定的页面
    $rootScope.logined = false;
    var user=JSON.parse(localStorage.getItem("user"));
    if(user){
        $rootScope.logined = true;
        if(user.headImg){
        	 $rootScope.userPic = user.headImg;
        }else{
        	 $rootScope.userPic = './img/images/user1.png';
        }
    }else{
        $rootScope.logined = false;
        $rootScope.userPic = './img/images/user1.png';
    }
    $rootScope.toLogin=function(){
    	var user=JSON.parse(localStorage.getItem("user"));
    	if(user){
    		window.location.href="index.html#/userCenter";
            $rootScope.logined = true;
    	}else{
    		window.location.href="index.html#/login";
            $rootScope.logined = false;
    	}
    };
    $rootScope.serviceUrl='http://114.214.164.24/api-gateway/app/';  
})
//路由
kexApp
    .config(["$stateProvider", "$urlRouterProvider", function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise("/bookstack");
        $stateProvider
            .state('selfbook', {
                url: '/selfbook',
                templateUrl: "templates/selfbook.html",
                controller: "selfCtrl"
            })
            .state('bookstack', {
                url: '/bookstack',
                templateUrl: "templates/bookstack.html",
                controller: "stackCtrl"
            })
            .state('details', {
                url: '/details/:detailId',
                templateUrl: "templates/details.html",
                controller: "detailCtrl"
            })
            .state('update', {
                url: '/update',
                templateUrl: "templates/update.html",
                controller: "updateCtrl"
            })
            .state('circum', {
                url: '/circum',
                templateUrl: "templates/circum.html",
                controller: "circumCtrl"
            })
            .state('search',{
                url:'/search',
                templateUrl:'templates/search.html',
                controller:'searchCtrl'
            })
            .state('login', {
                url: '/login',
                templateUrl: "templates/login.html",
                controller: "loginCtrl"
            })
            .state('register', {
                url: '/register',
                templateUrl: "templates/register.html",
                controller: "registerCtrl"
            })
            .state('reset', {
                url: '/reset',
                templateUrl: "templates/reset.html",
                controller: "resetCtrl"
            })
            .state('userCenter', {
                url: '/userCenter',
                templateUrl: "templates/userCenter.html",
                controller: "userCenterCtrl"
            })
            .state('change', {
                url: '/change',
                templateUrl: "templates/change.html",
                controller: "changeCtrl"
            })
            .state('recharge', {
                url: '/recharge',
                templateUrl: "templates/recharge.html",
                controller: "rechargeCtrl"
            })
            .state('uptag', {
                url: '/uptag',
                templateUrl: "templates/uptag.html",
                controller: "uptagCtrl"
            })
            .state('upImg', {
                url: '/upImg',
                templateUrl: "templates/upImg.html",
                controller: "upImgCtrl"
            })
            .state('classify',{
                url: '/classify',
                templateUrl: "templates/classify.html",
                controller: "classify"
            })
            .state('classifyBooks',{
                url: '/classifyBooks/:type',
                templateUrl: "templates/classifyBooks.html",
                controller: "classifyBooksCtr"
            })
            .state('myOrder',{
                url: '/myOrder',
                templateUrl: "templates/myOrder.html",
                controller: "myOrderCtrl"
            })
            .state('myOrderLogs',{
                url: '/myOrderLogs',
                templateUrl: "templates/myOrderLogs.html",
                controller: "myOrderLogsCtrl"
            })
            .state('myFocus',{
                url: '/myFocus',
                templateUrl: "templates/myFocus.html",
                controller: "myFocusCtrl"
            })
            .state('mediaShow',{
                url: '/mediaShow',
                templateUrl: "templates/mediaShow.html",
                controller: "mediaShowCtr"
            })
    }])

//定义全局变量
kexApp.kexJson = []





















